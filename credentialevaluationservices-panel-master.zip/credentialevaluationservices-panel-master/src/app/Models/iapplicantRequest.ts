import {IBase} from './ibase';
import {ICountry} from './icountry';
import {IGrade} from './igrade';
import {IUniversity} from './iuniversity';
import {IApplicants} from './iapplicants';
import {IRequest} from './irequest';

export interface IApplicantRequest {
  applicants: IApplicants;
  requestsList: IRequest[];
}
