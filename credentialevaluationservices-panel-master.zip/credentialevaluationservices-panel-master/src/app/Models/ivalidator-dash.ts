import {IBase} from './ibase';
import {IMassage} from './imassage';
import {IChart} from './ichart';

export interface IValidatorDash extends IBase {
  requests: number;
  remaining: number;
  chart: IChart[];
  messages: IMassage[];
}
