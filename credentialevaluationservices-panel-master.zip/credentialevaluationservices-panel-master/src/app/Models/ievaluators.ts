import {IBase} from './ibase';
import {IMassage} from './imassage';
import {IUniversity} from './iuniversity';

export interface IEvaluators extends IBase {
  name: string;
  username: string;
  password: string;
  email: string;
  avatar: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  university: IUniversity;
  messages: IMassage[];
}
