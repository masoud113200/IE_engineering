export interface Iadmin {
  username: string;
  password: string;
  avatar: string;
}
