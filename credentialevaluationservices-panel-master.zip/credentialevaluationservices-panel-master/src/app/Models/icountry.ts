import {IBase} from './ibase';

export interface ICountry extends IBase {
  name: string;
}
