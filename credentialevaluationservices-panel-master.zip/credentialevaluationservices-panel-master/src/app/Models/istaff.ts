import {IBase} from './ibase';
import {IMassage} from './imassage';
import {Iorganizations} from './iorganizations';

export interface Istaff extends IBase {
  name: string;
  username: string;
  password: string;
  email: string;
  avatar: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  organizations: Iorganizations;
  messages: IMassage[];
}
