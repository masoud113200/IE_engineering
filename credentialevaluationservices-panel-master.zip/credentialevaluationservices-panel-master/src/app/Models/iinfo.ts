export interface IInfo {
  id: string;
  username: string;
  password: string;
  avatar: string;
  userType: string;
}
