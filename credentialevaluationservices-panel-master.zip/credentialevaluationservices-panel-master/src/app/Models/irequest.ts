import {IBase} from './ibase';
import {ICountry} from './icountry';
import {IGrade} from './igrade';
import {IUniversity} from './iuniversity';

export interface IRequest extends IBase {
  degreeImage: string;
  startDate: string;
  endDate: string;
  faculty: string;
  major: string;
  description: string;
  country: ICountry;
  grade: IGrade;
  originUniversity: IUniversity;
  destinationUniversities: IUniversity[];
  comment: string;
  status: number;
  key: string;
}
