import {IBase} from './ibase';
import {IMassage} from './imassage';
import {ICountry} from './icountry';
import {IRequest} from './irequest';

export interface IApplicants extends IBase {
  name: string;
  username: string;
  password: string;
  email: string;
  birthDate: string;
  gender: string;
  avatar: string;
  firstName: string;
  lastName: string;
  middleName: string;
  knownAs: string;
  fatherName: string;
  motherName: string;
  phoneNumber: string;
  mobileNumber: string;
  nationalCode: string;
  passportNumber: string;
  address: string;
  country: ICountry;
  cityBirth: string;
  stateBirth: string;
  countryOfNationality: string;
  requests: IRequest[];
  messages: IMassage[];
}
