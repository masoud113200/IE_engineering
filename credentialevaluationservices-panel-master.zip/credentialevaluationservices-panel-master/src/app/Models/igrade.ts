import {IBase} from './ibase';

export interface IGrade extends IBase {
  name: string;
}
