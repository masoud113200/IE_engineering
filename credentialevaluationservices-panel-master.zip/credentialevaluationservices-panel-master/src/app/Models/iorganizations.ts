import {IBase} from './ibase';
import {ICountry} from './icountry';

 export interface Iorganizations extends IBase {
  name: string;
  email: string;
  webSite: string;
  phoneNumber: string;
  address: string;
  image: string;
  country: ICountry;
}
