import {IChart} from './ichart';
import {IMassage} from './imassage';

export interface IAdminDash {
  applicants: number;
  evaluators: number;
  requests: number;
  accepted: number;
  chart: IChart[];
  messages: IMassage[];

}
