import {IBase} from './ibase';

export interface IMassage extends IBase {
  title: string;
  text: string;
}
