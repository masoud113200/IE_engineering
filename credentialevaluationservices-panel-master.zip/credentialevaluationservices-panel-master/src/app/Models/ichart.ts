export interface IChart {
  date: string;
  value: string;
}
