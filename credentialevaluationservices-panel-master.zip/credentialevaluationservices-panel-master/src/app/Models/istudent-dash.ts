import {IBase} from './ibase';
import {IMassage} from './imassage';

export interface IStudentDash extends IBase {
  messages: number;
  credit: number;
  accepted: number;
  requests: number;
  messageList: IMassage[];

}
