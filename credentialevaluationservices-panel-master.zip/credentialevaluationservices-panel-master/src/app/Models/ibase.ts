export interface IBase {
  id: number;
  created: string;
  updated: string;
  verified: boolean;
}
