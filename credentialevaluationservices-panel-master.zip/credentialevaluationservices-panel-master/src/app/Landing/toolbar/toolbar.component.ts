import {Component, OnInit} from '@angular/core';
import {InfoService} from '../../info.service';
import {ActivatedRoute, Router} from '@angular/router';
import {GlobalVariable} from '../../globalVariable';
import {CookieConsent} from '../../cookie-consent.service';

@Component({
  selector: 'app-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.css']
})
export class ToolbarComponent implements OnInit {

  constructor(public infoService: InfoService, private router: Router, private route: ActivatedRoute,
              private gv: GlobalVariable, private cookieService: CookieConsent) {
  }

  username = '';
  thumbnail = '';

  ngOnInit() {
    this.username = this.cookieService.getCookie('userName');
    this.thumbnail = this.gv.baseURLFiles + this.cookieService.getCookie('avatar');
    this.infoService.avatar = this.thumbnail;
    this.infoService.username = this.username;
    this.infoService.id = this.cookieService.getCookie('id');
    this.infoService.userType = this.cookieService.getCookie('userType');
  }

  signOutClick() {
    this.cookieService.deleteCookie('logged');
    this.router.navigate(['/'], {relativeTo: this.route, skipLocationChange: true});
  }
}
