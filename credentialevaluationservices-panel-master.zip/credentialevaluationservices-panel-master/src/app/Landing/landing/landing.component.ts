import {Component, OnInit} from '@angular/core';
import {InfoService} from '../../info.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  constructor(private info: InfoService, private router: Router) {
  }

  ngOnInit() {

  }

  onClick() {
    if (this.info.userType === '0') {
      this.router.navigate(['main/adminDashboard']);
    } else if (this.info.userType === '1') {
      this.router.navigate(['main/validatorDashboard']);

    } else if (this.info.userType === '2') {
      this.router.navigate(['main/studentDashboard']);
    } else if (this.info.userType === '3') {
      this.router.navigate(['main/staffDashboard']);
    }
  }
}
