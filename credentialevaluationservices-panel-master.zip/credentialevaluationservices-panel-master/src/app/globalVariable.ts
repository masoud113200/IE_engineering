export class GlobalVariable {
  baseURLFiles = 'http://185.119.166.167:5902/files/';
  baseURL = 'http://185.119.166.167:5902/web/';
  addMedia = this.baseURL + 'uploads/file';

  loginPost = this.baseURL + 'login';
  countriesPost = this.baseURL + 'countries';
  countriesGet = this.baseURL + 'countries';
  gradesPost = this.baseURL + 'grades';
  gradesGet = this.baseURL + 'grades';
  applicantsPost = this.baseURL + 'applicants';
  applicantsGet = this.baseURL + 'applicants';
  universitiesPost = this.baseURL + 'universities';
  universitiesGet = this.baseURL + 'universities';
  universitiesDel = this.baseURL + 'universities';
  organizationsPost = this.baseURL + 'organizations';
  organizationsGet = this.baseURL + 'organizations';
  evaluatorsGet = this.baseURL + 'evaluators';
  evaluatorsPost = this.baseURL + 'evaluators';
  staffGet = this.baseURL + 'staffs';
  staffPost = this.baseURL + 'staffs';
  requestPost = this.baseURL + 'requests/status/';
  request = this.baseURL + 'requests/';
  requestOrganizationsPost = this.baseURL + 'requests/organizations/';
  requestPostComment = this.baseURL + 'requests/comment/';
  requestDel = this.baseURL + 'requests/';
  requestUpdate = this.baseURL + 'requests/';
  requestGet = this.baseURL + 'requests/applicant/';
  applicantRequestGet = this.baseURL + 'requests/evaluator/';
  applicantRequestDestinationGet = this.baseURL + 'requests/staff/';
  adminDashGet = this.baseURL + 'admin/info';
  applicantDashGet = this.baseURL + 'applicants/info/';
  validatorDashGet = this.baseURL + 'evaluators/info/';
  staffDashGet = this.baseURL + 'staffs/info/';
  messageValidator = this.baseURL + 'messages/evaluator/';
  messageApplicant = this.baseURL + 'messages/applicant/';
  messageStaff = this.baseURL + 'messages/staff/';

  adminGet = this.baseURL + 'admin';
  adminPost = this.baseURL + 'admin';
}
