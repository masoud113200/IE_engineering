import {Component, OnInit} from '@angular/core';
import {InfoService} from '../../info.service';
import {Router} from '@angular/router';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';
import {AuthenticationService} from '../../authentication.service';
import {CookieConsent} from '../../cookie-consent.service';
import {ToastService} from '../../toast.service';
import {MatSnackBar} from '@angular/material';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {

  constructor(private info: InfoService, private router: Router, private networks: NetworksService,
              private gv: GlobalVariable, private spinnerService: Ng4LoadingSpinnerService,
              private authenticationService: AuthenticationService, private cookieService: CookieConsent,
              private toast: ToastService, private snackBar: MatSnackBar) {

  }


  username = '';
  password = '';
  isRobot = false;
  isRobotCheck = true;
  res = 'Please Fill Recaptcha';

  ngOnInit() {
  }


  onLogin() {
    if (this.username === '' || this.password === '') {
      this.res = 'Please Insert Username and Password';
      this.isRobotCheck = false;
      return;
    }

    if (this.isRobot === true) {
      this.isRobotCheck = true;


      this.authenticationService.authentication({
        'username': this.username,
        'password': this.password
      }).subscribe((response) => {
        this.snackBar.open('Welcome', this.username, {
          duration: 2000,
          verticalPosition: 'top'
        });
        this.info.id = response['id'];
        this.info.username = response['username'];
        this.info.password = response['password'];
        this.info.avatar = response['avatar'];
        this.info.userType = response['userType'];
        this.cookieService.setCookie('userName', response['username'] + '', 10, '');
        this.cookieService.setCookie('logged', 'true', 10, '');
        this.cookieService.setCookie('id', response['id'] + '', 10, '');
        this.cookieService.setCookie('avatar', response['avatar'], 10, '');
        this.cookieService.setCookie('userType', response['userType'] + '', 10, '');
        this.router.navigate(['main']);
        this.authenticationService.isLogin = true;
      }, (error: Error) => {
        this.toast.toast('error', 'Error', 'Username or Password is incorrect ');
      }, () => {
        this.spinnerService.hide();
      });
    } else {
      this.isRobotCheck = false;
      this.res = 'Please Fill Recaptcha';
    }
  }

  onClickForget() {
    this.toast.toast('info', 'Info', 'Please contact your Administrator.');
  }

  resolved(captchaResponse: string) {
    this.isRobot = true;
  }
}
