///<reference path="../../node_modules/@angular/router/src/interfaces.d.ts"/>
import {Injectable} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, CanActivateChild, CanDeactivate, Router, RouterStateSnapshot} from '@angular/router';
import {Observable} from 'rxjs';
import {AuthenticationService} from './authentication.service';
import {InfoService} from './info.service';
import {CookieConsent} from './cookie-consent.service';


@Injectable()
export class AutGard implements CanActivate, CanDeactivate<Boolean> {

  constructor(private authenticationService: AuthenticationService, private router: Router,
              private cookieService: CookieConsent, private info: InfoService) {
  }

  cookieValue = 'UNKNOWN';

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

    this.cookieValue = this.cookieService.getCookie('logged');

    if (this.cookieValue === 'true') {
      return true;
    }

    if (!this.authenticationService.isLogin) {
      this.router.navigate(['login']);
    } else {
      this.cookieService.setCookie('logged', 'true', 10, '');

    }
    return this.authenticationService.isLogin;
  }

  canDeactivate(component: false, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot,
                nextState?: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return true;
  }


}
