import {Component, OnInit} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';
import {MatSnackBar} from '@angular/material';
import {InfoService} from '../../info.service';

@Component({
  selector: 'app-history',
  templateUrl: './historyValidator.component.html',
  styleUrls: ['./historyValidator.component.css']
})
export class HistoryValidatorComponent implements OnInit {

  constructor(private networks: NetworksService, public  gv: GlobalVariable,
              private spinnerService: Ng4LoadingSpinnerService, private snackBar: MatSnackBar, private info: InfoService) {
  }

  listRequest = [];
  listRequest2 = [];
  listRequestSub = [];
  listRequestSub2 = [];
  editable = false;
  isSelectedMain = false;
  isSelectedSub = false;
  result = 'no Action';
  selectedStyle = 'alert alert-danger';
  imageFileSaved = '';
  saveComment = '';

  username = '';
  email = '';
  birthDate = '';
  gender = '';
  firstName = '';
  lastName = '';
  middleName = '';
  knownAs = '';
  fatherName = '';
  motherName = '';
  mobileNumber = '';
  nationalCode = '';
  passportNumber = '';
  address = '';
  country = '';
  applicantId = 0;

  degreeImage = '';
  startDateR = '';
  endDateR = '';
  facultyR = '';
  majorR = '';
  descriptionR = '';
  gradeR = '';
  LitigationUniversities = [];
  status = 0;
  requestId = 0;
  resultArray = ['No Action', 'In progress', 'Rejected', 'Accepted'];
  color = ['black', 'blue', 'red', 'green'];

  ngOnInit() {
    this.load();
  }

  Filter(event) {
    const val = event.target.value.toLowerCase();
    this.listRequest = this.listRequest2;
    this.listRequest = this.listRequest.filter(function (d) {
      return d.username.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }

  FilterS(event) {
    const val = event.target.value.toLowerCase();
    this.listRequestSub = this.listRequestSub2;
    this.listRequestSub = this.listRequestSub.filter(function (d) {
      return d.grade.name.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }

  load() {
    this.networks.getApplicantRequest(this.gv.applicantRequestGet + this.info.id).subscribe((response) => {
      this.listRequest = response;
      this.listRequest2 = response;
    });
  }

  onSelect({selected}) {
    this.isSelectedMain = true;
    this.isSelectedSub = false;

    this.listRequestSub = selected[0].requests;
    this.listRequestSub2 = selected[0].requests;

    this.username = selected[0].username;
    this.email = selected[0].email;
    this.birthDate = selected[0].birthDate;
    this.gender = selected[0].gender;
    this.firstName = selected[0].firstName;
    this.lastName = selected[0].lastName;
    this.middleName = selected[0].middleName;
    this.knownAs = selected[0].knownAs;
    this.fatherName = selected[0].fatherName;
    this.motherName = selected[0].motherName;
    this.mobileNumber = selected[0].mobileNumber;
    this.nationalCode = selected[0].nationalCode;
    this.passportNumber = selected[0].passportNumber;
    this.address = selected[0].address;
    this.country = selected[0].country.name;
    this.applicantId = selected[0].id;


  }

  onSelectSub({selected}) {
    this.isSelectedSub = true;
    this.degreeImage = selected[0].degreeImage;
    this.startDateR = selected[0].startDate;
    this.endDateR = selected[0].endDate;
    this.facultyR = selected[0].faculty;
    this.majorR = selected[0].major;
    this.descriptionR = selected[0].description;
    this.gradeR = selected[0].grade.name;
    this.LitigationUniversities = selected[0].destinationUniversities;
    this.status = selected[0].status;
    this.requestId = selected[0].id;
    this.imageFileSaved = selected[0].degreeImage;
    this.saveComment = selected[0].comment;

    if (this.status === 3) {
      this.result = 'Request is Accepted';
      this.editable = false;
      this.selectedStyle = 'alert alert-success';
    } else if (this.status === 0) {
      this.result = 'No Action';
      this.selectedStyle = '';
      this.editable = true;

    } else if (this.status === 2) {
      this.result = 'Request is Rejected';
      this.selectedStyle = 'alert alert-danger';
      this.editable = true;

    } else if (this.status === 1) {
      this.result = 'Request is in Progress';
      this.selectedStyle = 'alert alert-info';
      this.editable = true;

    }
  }


  sendComment() {
    if (this.saveComment === '') {
      this.snackBar.open('Error', 'Please Insert Message', {
        duration: 2000, verticalPosition: 'top'
      });
      return;
    }
    this.networks.Post(this.gv.requestPostComment + this.applicantId + '/' + this.requestId, {
      'string': this.saveComment
    }).subscribe(() => {
      this.load();
      this.snackBar.open('Success', 'Comment Add Successfully', {
        duration: 2000, verticalPosition: 'top'
      });
    }, () => {
    }, () => {
    });
  }

  acceptClick() {
    if (confirm('Are You Sure Accept?')) {
      this.networks.getStatus(this.gv.requestPost + this.applicantId + '/' + this.requestId + '/' + 3).subscribe(() => {
        this.snackBar.open('Success', 'Request Accepted', {
          duration: 2000, verticalPosition: 'top'
        });
        this.load();
        this.isSelectedMain = false;
        this.isSelectedSub = false;
      }, () => {
      }, () => {
      });
    }
  }

  rejectClick() {
    if (confirm('Are You Sure Reject?')) {
      this.networks.getStatus(this.gv.requestPost + this.applicantId + '/' + this.requestId + '/' + 2).subscribe(() => {
        this.snackBar.open('Success', 'Request Rejected', {duration: 2000, verticalPosition: 'top'});
        this.load();
        this.isSelectedMain = false;
        this.isSelectedSub = false;
      }, () => {
      }, () => {
      });
    }
  }

  inProgress() {
    if (confirm('Are You Sure in Progress?')) {
      this.networks.getStatus(this.gv.requestPost + this.applicantId + '/' + this.requestId + '/' + 1).subscribe(() => {
        this.snackBar.open('Success', 'Request inProgress', {duration: 2000, verticalPosition: 'top'});
        this.load();
        this.isSelectedMain = false;
        this.isSelectedSub = false;
      }, () => {
      }, () => {
      });

    }
  }

  saveCommentClick() {

  }

  onSubmit() {
    this.spinnerService.show();
  }

}
