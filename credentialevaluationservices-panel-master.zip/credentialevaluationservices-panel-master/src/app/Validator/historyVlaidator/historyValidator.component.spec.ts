import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HistoryValidatorComponent } from './historyValidator.component';

describe('HistoryValidatorComponent', () => {
  let component: HistoryValidatorComponent;
  let fixture: ComponentFixture<HistoryValidatorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HistoryValidatorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HistoryValidatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
