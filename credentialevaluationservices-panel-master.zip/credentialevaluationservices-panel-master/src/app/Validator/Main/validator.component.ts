import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {DeviceDetectorService} from 'ngx-device-detector';

declare var xJS: any;


@Component({
  selector: 'app-validator',
  templateUrl: './validator.component.html',
  styleUrls: ['./validator.component.css']
})
export class ValidatorComponent implements OnInit {
  status = true;

  constructor(private router: Router, private route: ActivatedRoute, private deviceService: DeviceDetectorService) {

  }

  ngOnInit() {
  }

  menuSlid() {
    this.status = !this.status;
  }

  dash() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['dashboard'], {relativeTo: this.route});
      }, 600);
    } else {
      this.router.navigate(['dashboard'], {relativeTo: this.route});
    }
  }

  requestList() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['requestList'], {relativeTo: this.route});
      }, 600);
    } else {
      this.router.navigate(['requestList'], {relativeTo: this.route});

    }
  }
}
