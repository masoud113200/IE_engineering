import {Injectable} from '@angular/core';

@Injectable()
export class InfoService {
  id = '0';
  username = '';
  password = '';
  avatar = '';
  userType = '0';
}
