import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {LoginComponent} from './Main/login/login.component';
import {MainComponent} from './Student/main/main.component';
import {SignUpComponent} from './Student/sign-up/sign-up.component';
import {ValidatorComponent} from './Validator/Main/validator.component';
import {AdminComponent} from './Admin/Main/admin.component';
import {ToolbarComponent} from './Landing/toolbar/toolbar.component';
import {LandingComponent} from './Landing/landing/landing.component';
import {PricingComponent} from './Landing/pricing/pricing.component';
import {IntroComponent} from './Landing/intro/intro.component';
import {AngularFontAwesomeModule} from 'angular-font-awesome';
import {RequestComponent} from './Student/request/request.component';
import {HistoryComponent} from './Student/history/history.component';
import {NgxDatatableModule} from '@swimlane/ngx-datatable';
import {Ng4LoadingSpinnerModule} from 'ng4-loading-spinner';
import {MatCardModule} from '@angular/material/card';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {
  MatDialogModule,
  MatExpansionModule,
  MatFormFieldModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatNativeDateModule, MatSnackBarModule
} from '@angular/material';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatSidenavModule} from '@angular/material/sidenav';

import {HistoryValidatorComponent} from './Validator/historyVlaidator/historyValidator.component';
import {StudentDashboardComponent} from './Student/student-dashbaord/student-dashboard.component';
import {AdminDashboardComponent} from './Admin/admin-dashboard/admin-dashboard.component';
import {ValidatorDashboardComponent} from './Validator/validator-dashboard/validator-dashboard.component';
import {SharedModule} from './shared/shared.module';
import {FormsModule} from '@angular/forms';
import {GlobalVariable} from './globalVariable';
import {UsersComponent} from './Admin/users/users.component';
import {ConfigComponent} from './Admin/config/config.component';
import {ValidatorConfigComponent} from './Admin/validator-config/validator-config.component';
import {FroalaEditorModule, FroalaViewModule} from 'angular-froala-wysiwyg';
import {InfoService} from './info.service';
import {AppMainComponent} from './Main/app-main/app-main.component';
import {FooterComponent} from './Landing/footer/footer.component';
import {UniversityComponent} from './Admin/university/university.component';
import {FaqComponent} from './Landing/faq/faq.component';
import {UpdateProfileComponent} from './Student/update-profile/update-profile.component';
import {CookieConsent} from './cookie-consent.service';
import {AutGard} from './aut-gard.service';
import {OrganizationsComponent} from './Admin/organizations/organizations.component';
import {StaffConfigComponent} from './Admin/staff/staffConfig.component';
import { NotifierOptions} from 'angular-notifier';
import {SweetAlert2Module} from '@toverux/ngx-sweetalert2';
import {ToastService} from './toast.service';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import {StaffDashboardComponent} from './Staff/staff-dashboard/staff-dashboard.component';
import {StaffComponent} from './Staff/Main/staff.component';
import {RepositoryComponent} from './Staff/repository/repository.component';
import {CustomFormsModule} from 'ng2-validation';
import {QuillModule} from 'ngx-quill';
import {RecaptchaModule} from 'ng-recaptcha';

import { DeviceDetectorModule } from 'ngx-device-detector';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MainComponent,
    SignUpComponent,
    ValidatorComponent,
    AdminComponent,
    ToolbarComponent,
    LandingComponent,
    PricingComponent,
    IntroComponent,
    RequestComponent,
    HistoryComponent,
    HistoryValidatorComponent,
    StudentDashboardComponent,
    AdminDashboardComponent,
    ValidatorDashboardComponent,
    UsersComponent,
    ConfigComponent,
    ValidatorConfigComponent,
    SignUpComponent,
    AppMainComponent,
    FooterComponent,
    UniversityComponent,
    FaqComponent,
    UpdateProfileComponent,
    OrganizationsComponent,
    StaffConfigComponent,
    StaffDashboardComponent,
    StaffComponent,
    RepositoryComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFontAwesomeModule,
    NgxDatatableModule,
    Ng4LoadingSpinnerModule.forRoot(),
    MatCardModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatIconModule,
    MatInputModule,
    MatDialogModule,
    MatListModule,
    MatExpansionModule,
    BrowserAnimationsModule,
    MatSnackBarModule,
    MatSidenavModule,
    SharedModule,
    FormsModule,
    SweetAlert2Module.forRoot(),
    CustomFormsModule,
    QuillModule.forRoot(),
    RecaptchaModule.forRoot(),
    DeviceDetectorModule.forRoot()
  ],
  providers: [MatDatepickerModule, GlobalVariable, InfoService, AutGard, CookieConsent, ToastService,
    {provide: LocationStrategy, useClass: HashLocationStrategy}
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
