import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {GlobalVariable} from './globalVariable';
import {ActivatedRoute, Router} from '@angular/router';
import {Ilogin} from './Models/ilogin';
import {IInfo} from './Models/iinfo';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  isLogin = false;

  constructor(private  http: HttpClient, private gv: GlobalVariable, private router: Router, private  route: ActivatedRoute) {
  }

  authentication(userLogin: Ilogin) {
    return this.http.post<IInfo>(this.gv.loginPost, userLogin);
  }

}
