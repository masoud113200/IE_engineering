import {Injectable} from '@angular/core';
import swal, {SweetAlertType} from 'sweetalert2';

@Injectable()
export class ToastService {

  constructor() {
  }


  public  toast(type: SweetAlertType, title: string, message: string) {
    swal({
      type: type,
      title: title,
      text: message
    });
  }
}
