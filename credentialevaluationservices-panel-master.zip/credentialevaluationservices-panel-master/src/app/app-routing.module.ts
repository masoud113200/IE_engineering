import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {LandingComponent} from './Landing/landing/landing.component';
import {MainComponent} from './Student/main/main.component';
import {RequestComponent} from './Student/request/request.component';
import {HistoryComponent} from './Student/history/history.component';
import {AdminComponent} from './Admin/Main/admin.component';
import {ValidatorComponent} from './Validator/Main/validator.component';
import {StudentDashboardComponent} from './Student/student-dashbaord/student-dashboard.component';
import {AdminDashboardComponent} from './Admin/admin-dashboard/admin-dashboard.component';
import {ValidatorDashboardComponent} from './Validator/validator-dashboard/validator-dashboard.component';
import {HistoryValidatorComponent} from './Validator/historyVlaidator/historyValidator.component';
import {ValidatorConfigComponent} from './Admin/validator-config/validator-config.component';
import {UsersComponent} from './Admin/users/users.component';
import {ConfigComponent} from './Admin/config/config.component';
import {LoginComponent} from './Main/login/login.component';
import {AppMainComponent} from './Main/app-main/app-main.component';
import {SignUpComponent} from './Student/sign-up/sign-up.component';
import {UniversityComponent} from './Admin/university/university.component';
import {FaqComponent} from './Landing/faq/faq.component';
import {UpdateProfileComponent} from './Student/update-profile/update-profile.component';
import {AutGard} from './aut-gard.service';
import {OrganizationsComponent} from './Admin/organizations/organizations.component';
import {StaffConfigComponent} from './Admin/staff/staffConfig.component';
import {StaffDashboardComponent} from './Staff/staff-dashboard/staff-dashboard.component';
import {RepositoryComponent} from './Staff/repository/repository.component';
import {StaffComponent} from './Staff/Main/staff.component';

const routes: Routes = [
  {path: '', component: LoginComponent},
  {path: 'login', component: LoginComponent},
  {path: 'sign-up', component: SignUpComponent},
  {
    path: 'main', canActivate: [AutGard],  component: AppMainComponent, children: [
      {path: '', component: LandingComponent},
      {path: 'faq', component: FaqComponent},
      {
        path: 'studentDashboard', component: MainComponent, children: [
          {path: '', component: StudentDashboardComponent},
          {path: 'dashboard', component: StudentDashboardComponent},
          {path: 'request', component: RequestComponent},
          {path: 'history', component: HistoryComponent},
          {path: 'updateProfile', component: UpdateProfileComponent},
          ]
      }, {
        path: 'adminDashboard', component: AdminComponent, children: [
          {path: '', component: AdminDashboardComponent},
          {path: 'dashboard', component: AdminDashboardComponent},
          {path: 'Validator', component: ValidatorConfigComponent},
          {path: 'organizations', component: OrganizationsComponent},
          {path: 'staff', component: StaffConfigComponent},
          {path: 'Users', component: UsersComponent},
          {path: 'University', component: UniversityComponent},
          {path: 'Config', component: ConfigComponent}]
      }, {
        path: 'validatorDashboard', component: ValidatorComponent, children: [
          {path: '', component: ValidatorDashboardComponent},
          {path: 'dashboard', component: ValidatorDashboardComponent},
          {path: 'requestList', component: HistoryValidatorComponent}]
      }, {
        path: 'staffDashboard', component: StaffComponent, children: [
          {path: '', component: StaffDashboardComponent},
          {path: 'dashboard', component: StaffDashboardComponent},
          {path: 'repository', component: RepositoryComponent}]
      }]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes),
    RouterModule.forRoot(routes, { useHash: true })
  ],
  exports: [RouterModule]
})


export class AppRoutingModule {


}
