import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {ICountry} from './Models/icountry';
import {IGrade} from './Models/igrade';
import {IApplicants} from './Models/iapplicants';
import {IEvaluators} from './Models/ievaluators';
import {IUniversity} from './Models/iuniversity';
import {IRequest} from './Models/irequest';
import {IApplicantRequest} from './Models/iapplicantRequest';
import {IAdminDash} from './Models/iadmin-dash';
import {IStudentDash} from './Models/istudent-dash';
import {Istaff} from './Models/istaff';
import {Iorganizations} from './Models/iorganizations';
import {Iadmin} from './Models/iadmin';
import {IValidatorDash} from './Models/ivalidator-dash';

@Injectable({
  providedIn: 'root'
})
export class NetworksService {

  constructor(private http: HttpClient) {
  }

  Post(url: string, data: any) {
    return this.http.post(url, data);
  }

  getVerified(url: string): Observable<string> {
    return this.http.get<string>(url);
  }

  getCountry(url: string): Observable<ICountry[]> {
    return this.http.get<ICountry[]>(url);
  }

  getGrad(url: string): Observable<IGrade[]> {
    return this.http.get<IGrade[]>(url);
  }

  getApplicants(url: string): Observable<IApplicants[]> {
    return this.http.get<IApplicants[]>(url);
  }

  getApplicant(url: string): Observable<IApplicants> {
    return this.http.get<IApplicants>(url);
  }

  getRequest(url: string): Observable<IRequest[]> {
    return this.http.get<IRequest[]>(url);
  }

  getApplicantRequest(url: string): Observable<IApplicantRequest[]> {
    return this.http.get<IApplicantRequest[]>(url);
  }

  getEvaluators(url: string): Observable<IEvaluators[]> {
    return this.http.get<IEvaluators[]>(url);
  }

  getStaff(url: string): Observable<Istaff[]> {
    return this.http.get<Istaff[]>(url);
  }

  getUniversities(url: string): Observable<IUniversity[]> {
    return this.http.get<IUniversity[]>(url);
  }

  getOrganizations(url: string): Observable<Iorganizations[]> {
    return this.http.get<Iorganizations[]>(url);
  }

  getStatus(url: string) {
    return this.http.get(url);
  }

  del(url: string) {
    return this.http.delete(url);
  }

  getDashAdmin(url: string): Observable<IAdminDash> {
    return this.http.get<IAdminDash>(url);
  }

  getApplicantDash(url: string): Observable<IStudentDash> {
    return this.http.get<IStudentDash>(url);
  }

  getValidatorDash(url: string): Observable<IValidatorDash> {
    return this.http.get<IValidatorDash>(url);
  }

  getAdmin(url: string): Observable<Iadmin> {
    return this.http.get<Iadmin>(url);
  }

}
