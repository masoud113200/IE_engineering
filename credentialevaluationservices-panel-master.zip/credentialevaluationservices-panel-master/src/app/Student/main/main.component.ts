import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {DeviceDetectorService} from 'ngx-device-detector';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
  status = true;

  constructor(private router: Router, private route: ActivatedRoute, private deviceService: DeviceDetectorService) {

  }

  ngOnInit() {
  }

  menuSlid() {
    this.status = !this.status;
  }

  dash() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
    }
    setTimeout(() => {
      this.router.navigate(['dashboard'], {relativeTo: this.route});

    }, 600);
  }

  request() {

    if (this.deviceService.isMobile()) {
      this.status = !this.status;
    }
    setTimeout(() => {
      this.router.navigate(['request'], {relativeTo: this.route});

    }, 600);
  }

  history() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['history'], {relativeTo: this.route});
      }, 600);
    } else {
      this.router.navigate(['history'], {relativeTo: this.route});
    }
  }

  updateProfile() {

    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['updateProfile'], {relativeTo: this.route});
      }, 600);
    } else {
      this.router.navigate(['updateProfile'], {relativeTo: this.route});
    }
  }


}
