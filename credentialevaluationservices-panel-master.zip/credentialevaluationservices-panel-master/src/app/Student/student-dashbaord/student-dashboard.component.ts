import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {InfoService} from '../../info.service';

@Component({
  selector: 'app-student-dashbord',
  templateUrl: './student-dashboard.component.html',
  styleUrls: ['./student-dashboard.component.css']
})
export class StudentDashboardComponent implements OnInit {

  constructor(private networks: NetworksService, private gv: GlobalVariable, private info: InfoService) {
  }

  listMessage = [];
  isSelectMessage = false;
  Message = '';
  messageCount = 0;
  creditCount = 0;
  acceptedCount = 0;
  submittedCount = 0;
  name = '';

  ngOnInit() {
    this.load();
  }

  load() {
    this.networks.getApplicantDash(this.gv.applicantDashGet + this.info.id).subscribe((response) => {
      this.messageCount = response.messages;
      this.creditCount = response.credit;
      this.acceptedCount = response.accepted;
      this.submittedCount = response.requests;
      this.listMessage = response.messageList;
    });
  }

  onSelect({selected}) {
    this.isSelectMessage = true;
    this.Message = selected[0].text;
  }
}
