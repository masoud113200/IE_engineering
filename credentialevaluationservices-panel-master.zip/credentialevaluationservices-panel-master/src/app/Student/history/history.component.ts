import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';
import {IUniversity} from '../../Models/iuniversity';
import {ICountry} from '../../Models/icountry';
import {IGrade} from '../../Models/igrade';
import {InfoService} from '../../info.service';
import {Iorganizations} from '../../Models/iorganizations';
import {MatSnackBar} from '@angular/material';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css']
})
export class HistoryComponent implements OnInit {

  constructor(private networks: NetworksService, public  gv: GlobalVariable,
              private spinnerService: Ng4LoadingSpinnerService, private info: InfoService, private snackBar: MatSnackBar) {
  }

  @ViewChild('selectFilesUP') selectFilesInputUP: ElementRef;
  checkedList = [];
  imageFile: File;
  startDate = '';
  endDate = '';
  faculty = '';
  major = '';
  country = 0;
  grade = 0;

  originUniversityString = '';
  degreeString = '';
  countryString = '';

  originUniversity = 0;
  comment = '';
  accreditorComment = '';
  imageFileSaved = '';
  destinationUniversities = [];

  listUniversity = [];
  listOrganizations = [];
  listCountry = [];
  listDegree = [];
  listRequest = [];
  listRequest2 = [];
  isSelected = false;
  result = '';
  selectedStyle = 'alert alert-danger';
  editable = true;
  requestID = 0;
  status = 0;
  stringImageAddress = 'Choose file ...';
  listDestinationUniversity = [];
  resultArray = ['No Action', 'In progress', 'Rejected', 'Accepted'];
  color = ['black', 'blue', 'red', 'green'];
  orgiaiserListId = [];

  isDesabledOrginize = false;
  disList = [];

  ngOnInit() {
    this.load();
  }

  changeFile(event: string) {
    this.stringImageAddress = event;
  }

  Filter(event) {
    const val = event.target.value.toLowerCase();
    this.listRequest = this.listRequest2;
    this.listRequest = this.listRequest.filter(function (d) {
      return d.grade.name.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }


  load() {
    this.isSelected = false;
    this.networks.getRequest(this.gv.requestGet + this.info.id).subscribe((response) => {
      this.listRequest = response;
      this.listRequest2 = response;
      this.networks.getUniversities(this.gv.universitiesGet).subscribe((respondUni: IUniversity[]) => {
        this.listUniversity = respondUni;
      }, () => {
      }, () => {
      });
      this.networks.getOrganizations(this.gv.organizationsGet).subscribe((respondUni: Iorganizations[]) => {
        this.listOrganizations = respondUni.sort((obj1, obj2) => {
          if (obj1.id > obj2.id) {
            return 1;
          }
          if (obj1.id < obj2.id) {
            return -1;
          }
          return 0;
        });
      }, () => {
      }, () => {
      });
    }, () => {
    }, () => {
    });

    this.networks.getCountry(this.gv.countriesGet).subscribe((response: ICountry[]) => {
      this.listCountry = response;
    }, () => {
    }, () => {
    });
    this.networks.getGrad(this.gv.gradesGet).subscribe((response: IGrade[]) => {
      this.listDegree = response;
    }, () => {
    }, () => {
    });

  }

  onDestinationUniversitiesChange(e, v) {
    // console.log(e.option.value);
    // console.log(this.destinationUniversities);


    console.log(e.option.selected);
    if (e.option.selected) {
      if (!this.destinationUniversities.some(x => x === +e.option.value)) {
        this.destinationUniversities.push(+(e.option.value));
      }
    } else {
      if (this.destinationUniversities.some(x => x === +e.option.value)) {
        this.destinationUniversities.forEach((item, index) => {
          if (item === +e.option.value) {
            this.destinationUniversities.splice(index, 1);
          }
        });
        this.destinationUniversities.splice(+e.option.value);
      }
    }
    console.log(this.destinationUniversities);

  }

  onSelectCountry(selected) {
    this.country = selected;
    console.log(this.country);
    this.originUniversity = -1;

    this.networks.getUniversities(this.gv.universitiesGet + '/country/' + this.country).subscribe((response: IUniversity[]) => {
      this.listUniversity = response;
    }, () => {
    }, () => {
    });
  }

  onSelect({selected}) {
    this.isDesabledOrginize = false;

    this.isSelected = true;
    this.imageFileSaved = selected[0].degreeImage;
    this.startDate = selected[0].startDate;
    this.endDate = selected[0].endDate;
    this.faculty = selected[0].faculty;
    this.major = selected[0].major;
    this.comment = selected[0].description;
    this.accreditorComment = selected[0].comment;
    this.originUniversityString = selected[0].originUniversity.name;
    this.degreeString = selected[0].grade.name;
    this.country = selected[0].country.id;
    this.originUniversity = selected[0].originUniversity.id;
    this.grade = selected[0].grade.id;

    this.countryString = selected[0].country.name.trim();
    this.requestID = selected[0].id;
    this.status = selected[0].status;
    this.listDestinationUniversity = selected[0].destinationOrganizations;

    this.checkedList = [];
    this.destinationUniversities = [];
    this.orgiaiserListId = [];


    const li = [];

    this.listDestinationUniversity.forEach((value) => {

      if (!value.verified) {
        this.isDesabledOrginize = true;
        li.push(value);
      } else {
        this.destinationUniversities.push(value.id);

      }

    });
    this.disList = li;


    this.listOrganizations.forEach((value) => {
      this.orgiaiserListId.push(value.id);

    });


    this.orgiaiserListId = this.orgiaiserListId.sort((n1, n2) => n1 - n2);
    this.destinationUniversities = this.destinationUniversities.sort((n1, n2) => n1 - n2);


    let counter = 0;
    this.orgiaiserListId.forEach((value) => {
      if (this.destinationUniversities[counter] != null && value === this.destinationUniversities[counter]) {
        this.checkedList.push(true);
        counter++;
      } else {
        this.checkedList.push(false);
      }
    });
console.log(this.checkedList);

    if (this.status === 0) {
      this.result = '';
      this.selectedStyle = '';
      this.editable = true;
    } else if (this.status === 1) {
      this.result = 'Request is Progress';
      this.selectedStyle = 'alert alert-primary';
      this.editable = true;
    } else if (this.status === 3) {
      this.result = 'Request is Accepted';
      this.selectedStyle = 'alert alert-success';
      this.editable = false;
    } else if (this.status === 2) {
      this.result = 'Request is Rejected';
      this.selectedStyle = 'alert alert-danger';
      this.editable = true;
    }
  }

  onSelectOriginUniversity(selected) {
    this.originUniversity = selected;
  }

  onSelectGrade(selected) {
    this.grade = selected;
  }


  send() {
    const formData: FormData = new FormData();
    for (let i = 0; i < this.destinationUniversities.length; i++) {
      formData.append('destinationOrganizations', this.destinationUniversities[i]);
    }
    console.log(this.destinationUniversities);

    this.spinnerService.show();
    this.networks.Post(this.gv.requestOrganizationsPost + this.info.id + '/' + this.requestID, formData).subscribe((respone) => {
      this.snackBar.open('Success', 'Request Successfully Send', {duration: 2000, verticalPosition: 'top'});
      this.load();
    }, () => {
      this.snackBar.open('Error', 'Please Fill all Input', {
        duration: 2000,
        verticalPosition: 'top'
      });
      this.spinnerService.hide();

    }, () => {
      this.spinnerService.hide();
    });

  }

  onSubmit() {
    const formData: FormData = new FormData();
    const ImageFile = this.selectFilesInputUP.nativeElement;
    if (ImageFile.files && ImageFile.files[0]) {
      this.imageFile = ImageFile.files[0];
      const ImgFile: File = this.imageFile;
      formData.append('img', ImgFile);
    }
    formData.append('startDate', this.startDate);
    formData.append('endDate', this.endDate);
    formData.append('faculty', this.faculty);
    formData.append('major', this.major);
    formData.append('country', this.country + '');
    formData.append('originUniversity', this.originUniversity + '');
    formData.append('grade', this.grade + '');
    formData.append('description', this.comment);

    this.spinnerService.show();
    if (confirm('Are You Sure Update Request?')) {
      this.networks.Post(this.gv.requestUpdate + 'update/' + this.info.id + '/' + this.requestID, formData).subscribe((response) => {
        this.snackBar.open('Success', 'Request Successfully Updated', {duration: 2000, verticalPosition: 'top'});
        this.load();
      });
    }
  }

  onRemove() {
    if (confirm('Are You Sure Remove Request?')) {
      this.networks.del(this.gv.requestDel + this.info.id + '/' + this.requestID).subscribe((response) => {
        this.snackBar.open('Success', 'Request Successfully Send', {duration: 2000, verticalPosition: 'top'});
        this.load();
      });
    }
  }


}
