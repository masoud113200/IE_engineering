import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {ICountry} from '../../Models/icountry';
import {MatSnackBar} from '@angular/material';
import {Router} from '@angular/router';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';
import {ToastService} from '../../toast.service';
import * as EmailValidator from 'email-validator';
import {IApplicants} from '../../Models/iapplicants';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  @ViewChild('selectFilesUP') selectFilesInputUP: ElementRef;

  imageFile: File;
  username = '';
  password = '';
  email = '';
  birthDate1 = '';

  gender = 'm';
  firstName = '';
  lastName = '';
  middleName = '';
  knownAs = '';
  fatherName = '';
  motherName = '';
  phoneNumber = '';
  mobileNumber = '';
  nationalCode = '';
  passportNumber = '';
  address = '';
  country = 0;
  countryList = [];
  accepted = false;
  stringImageAddress = 'Choose file ...';
  EUsername = false;
  EPassword = false;
  EEmail = false;
  EbirthDate1 = false;
  EfirstName = false;
  ElastName = false;
  EnationalCode = false;
  ECountry = false;
  cantSubmit = false;
  EPassportCode = false;

  EphoneNumber = false;
  EmobileNumber = false;

  allAplicant: IApplicants[];
  allEmailS = [];

  constructor(private netWorks: NetworksService, private gv: GlobalVariable,
              private snackBar: MatSnackBar, private router: Router, private spinnerService: Ng4LoadingSpinnerService,
              private toast: ToastService) {
  }

  ngOnInit() {
    this.netWorks.getCountry(this.gv.countriesGet).subscribe((respone: ICountry[]) => {
      this.countryList = respone;
    }, () => {
    }, () => {
    });
    const allEmail = [];

    this.netWorks.getApplicants(this.gv.applicantsGet).subscribe((respone: IApplicants[]) => {
      this.allAplicant = respone;
      this.allAplicant.forEach(function (value) {
        allEmail.push(value.email.toString().toLowerCase().trim());
      });
    });
    this.allEmailS = allEmail;
  }

  changeFile(event: string) {
    this.stringImageAddress = event;
    console.log(event);
  }

  handleChangeM(evt) {
    const target = evt.target;
    if (target.checked) {
      this.gender = 'm';
    }
  }

  handleChangeF(evt) {
    const target = evt.target;
    if (target.checked) {
      this.gender = 'f';
    }
  }

  onSelectCountry(selected) {
    this.country = selected;
    this.ECountry = false;
  }

  isNumber(value: string | number): boolean {
    return !isNaN(Number(value.toString()));
  }

  inArray(needle: string, haystack: any): boolean {
    console.log(needle);
    console.log(haystack);
    const length = haystack.length;
    for (let i = 0; i < length; i++) {
      if (haystack[i].toString().toLowerCase().trim() === needle.toLowerCase().trim()) {
        return true;
      }
    }
    return false;
  }


  signUp() {
    if (!this.accepted) {
      this.toast.toast('error', 'Error', 'Please Accept Policy');
      this.cantSubmit = true;
      return;
    }
    if (this.username === '') {
      this.EUsername = true;
      this.cantSubmit = true;

    } else {
      this.EUsername = false;
    }
    if (this.password === '' || this.password.length < 6) {
      this.EPassword = true;
      this.cantSubmit = true;
      this.toast.toast('error', 'Error', 'Please Insert Safe Password');
      this.cantSubmit = false;
      return;
    } else {
      this.EPassword = false;
    }
    if (this.email === '') {
      this.EEmail = true;
      this.cantSubmit = true;

    } else {
      this.EEmail = false;
    }

    if (!EmailValidator.validate(this.email)) {
      this.EEmail = true;
      this.cantSubmit = true;

    } else {
      this.EEmail = false;
    }

    if (this.inArray(this.email, this.allEmailS)) {
      this.toast.toast('error', 'Error', 'This email is already exist');
      return;
    }
    if (this.firstName === '') {
      this.EfirstName = true;
      this.cantSubmit = true;

    } else {
      this.EfirstName = false;
    }
    if (this.lastName === '') {
      this.ElastName = true;
      this.cantSubmit = true;

    } else {
      this.ElastName = false;
    }
    if (this.nationalCode === '' || !this.isNumber(this.nationalCode)) {
      this.EnationalCode = true;
      this.cantSubmit = true;

    } else {
      this.EnationalCode = false;
    }
    if (this.birthDate1 === '') {
      this.EbirthDate1 = true;
      this.cantSubmit = true;

    } else {
      this.EbirthDate1 = false;
    }
    if (this.country === 0) {
      this.ECountry = true;
      this.cantSubmit = true;
    } else {
      this.ECountry = false;
    }

    if (!this.isNumber(this.mobileNumber)) {
      this.EmobileNumber = true;
      this.cantSubmit = true;
    } else {
      this.EmobileNumber = false;
    }

    if (!this.isNumber(this.phoneNumber)) {
      this.EphoneNumber = true;
      this.cantSubmit = true;
    } else {
      this.EphoneNumber = false;
    }

    if (!this.isNumber(this.passportNumber)) {
      this.EPassportCode = true;
      this.cantSubmit = true;
    } else {
      this.EPassportCode = false;
    }


    if (this.cantSubmit) {
      this.cantSubmit = false;
      this.toast.toast('error', 'Error', 'Please Insert All Required Input');
      return;
    }

    const formData: FormData = new FormData();
    const ImageFile = this.selectFilesInputUP.nativeElement;
    const fileExt = this.stringImageAddress.split('.').pop();
    if (fileExt !== 'jpg' && fileExt !== 'png' && fileExt !== 'PNG' && fileExt !== 'JPG') {
      this.toast.toast('error', 'Error', 'Please Insert Valid Image');
      return;
    }
    if (ImageFile.files && ImageFile.files[0]) {
      this.imageFile = ImageFile.files[0];
    } else {
      this.toast.toast('error', 'Error', 'Select User Image');
      return;
    }

    const ImgFile: File = this.imageFile;


    formData.append('img', ImgFile);
    formData.append('username', this.username);
    formData.append('password', this.password);
    formData.append('email', this.email);
    formData.append('birthDate', this.birthDate1);
    formData.append('gender', this.gender);
    formData.append('firstName', this.firstName);
    formData.append('lastName', this.lastName);
    formData.append('middleName', this.middleName);
    formData.append('knownAs', this.knownAs);
    formData.append('fatherName', this.fatherName);
    formData.append('motherName', this.motherName);
    formData.append('phoneNumber', this.phoneNumber);
    formData.append('mobileNumber', this.mobileNumber);
    formData.append('nationalCode', this.nationalCode);
    formData.append('passportNumber', this.passportNumber);
    formData.append('address', this.address);
    formData.append('country', this.country + '');
    this.spinnerService.show();
    this.netWorks.Post(this.gv.applicantsPost, formData).subscribe((respone) => {
      this.snackBar.open('Your registration has been successfully completed', this.username, {
        duration: 2000,
        verticalPosition: 'top'
      });
      this.spinnerService.hide();
      this.router.navigate(['']);
    }, () => {
      this.toast.toast('error', 'Error', 'Username Already Exist');
      this.spinnerService.hide();
    }, () => {
      this.spinnerService.hide();
    });
  }
}


