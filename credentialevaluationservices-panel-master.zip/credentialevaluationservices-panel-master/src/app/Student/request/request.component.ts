import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';
import {IUniversity} from '../../Models/iuniversity';
import {ICountry} from '../../Models/icountry';
import {IGrade} from '../../Models/igrade';
import {MatSnackBar} from '@angular/material';
import {InfoService} from '../../info.service';
import {Iorganizations} from '../../Models/iorganizations';
import {ToastService} from '../../toast.service';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {
  constructor(private networks: NetworksService, private netWorks: NetworksService, private gv: GlobalVariable,
              private snackBar: MatSnackBar,
              private spinnerService: Ng4LoadingSpinnerService, private info: InfoService,  private toast: ToastService) {
  }

  @ViewChild('selectFilesUP') selectFilesInputUP: ElementRef;
  imageFile: File;
  startDate = '';
  endDate = '';
  faculty = '';
  major = '';
  country = -1;
  grade = -1;
  originUniversity = -1;
  comment = '';
  destinationUniversities = [];
  stringImageAddress = 'Choose file ...';

  listOrganizations = [];
  listUniversity = [];
  listCountry = [];
  listDegree = [];

  Ccountry = 'Choose...';
  Cuniversity = 'Choose...';
  Cdegree = 'Choose...';

  onSelectOriginUniversity(selected) {
    this.originUniversity = selected;
    console.log(this.originUniversity);
  }

  onSelectGrade(selected) {
    this.grade = selected;
    console.log(this.grade);
  }

  changeFile(event: string) {
    this.stringImageAddress = event;
  }

  onSelectCountry(selected) {
    this.country = selected;
    console.log(this.country);
    this.originUniversity = -1;

    this.networks.getUniversities(this.gv.universitiesGet + '/country/' + this.country).subscribe((response: IUniversity[]) => {
      this.listUniversity = response;
    }, () => {
    }, () => {
    });
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.networks.getOrganizations(this.gv.organizationsGet).subscribe((response: Iorganizations[]) => {
      this.listOrganizations = response;
    }, () => {
    }, () => {
    });
    this.networks.getCountry(this.gv.countriesGet).subscribe((response: ICountry[]) => {
      this.listCountry = response;
    }, () => {
    }, () => {
    });
    this.networks.getGrad(this.gv.gradesGet).subscribe((response: IGrade[]) => {
      this.listDegree = response;
    }, () => {
    }, () => {
    });
  }

  onSubmit() {
    if (this.startDate === '' || this.endDate === '' || this.major === '' || this.faculty === '' ||
      this.country === -1 || this.originUniversity === -1 || this.grade === -1) {
      this.snackBar.open('Error', 'Please Insert All Input', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }

    const formData: FormData = new FormData();
    const ImageFile = this.selectFilesInputUP.nativeElement;
    if (ImageFile.files && ImageFile.files[0]) {
      this.imageFile = ImageFile.files[0];

    } else {
      this.snackBar.open('Error', 'Please Insert Picture of Academic degree', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    const ImgFile: File = this.imageFile;
    const fileExt = this.stringImageAddress.split('.').pop();
    if (fileExt !== 'jpg' && fileExt !== 'png' && fileExt !== 'PNG' && fileExt !== 'JPG') {
      this.toast.toast('error', 'Error', 'Please Insert Valid Image');
      return;
    }

    formData.append('img', ImgFile);
    formData.append('startDate', this.startDate);
    formData.append('endDate', this.endDate);
    formData.append('faculty', this.faculty);
    formData.append('major', this.major);
    formData.append('country', this.country + '');
    formData.append('originUniversity', this.originUniversity + '');
    formData.append('grade', this.grade + '');
    formData.append('description', this.comment);

    this.spinnerService.show();
    this.netWorks.Post(this.gv.request + '/add/' + this.info.id + '/' + this.originUniversity, formData).subscribe((respone) => {
      this.snackBar.open('Success', 'Your request sent successfully', {duration: 2000, verticalPosition: 'top'});
      this.startDate = '';
      this.endDate = '';
      this.faculty = '';
      this.major = '';
      this.comment = '';
      this.stringImageAddress = 'Choose file ...';
      this.Ccountry = 'Choose...';
      this.Cuniversity = 'Choose...';
      this.Cdegree = 'Choose...';
      this.country = -1;
      this.grade = -1;
      this.originUniversity = -1;
      this.listUniversity = [];
      this.listCountry = [];
      this.listDegree = [];
      this.spinnerService.hide();
      this.load();
    }, () => {
      this.snackBar.open('Error', 'Please Fill all Input', {
        duration: 2000,
        verticalPosition: 'top'
      });
      this.spinnerService.hide();

    }, () => {
      this.spinnerService.hide();
    });


  }
}
