import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {MatSnackBar} from '@angular/material';
import {Router} from '@angular/router';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';
import {ICountry} from '../../Models/icountry';
import {InfoService} from '../../info.service';
import {IApplicants} from '../../Models/iapplicants';
import {ToastService} from '../../toast.service';
import * as EmailValidator from 'email-validator';

@Component({
  selector: 'app-update-profile',
  templateUrl: './update-profile.component.html',
  styleUrls: ['./update-profile.component.css']
})
export class UpdateProfileComponent implements OnInit {

  @ViewChild('selectFilesUP') selectFilesInputUP: ElementRef;

  imageFile: File;
  username = '';
  password = '';
  email = '';
  birthDate1 = '';
  userImage = '';
  gender = '';
  firstName = '';
  lastName = '';
  middleName = '';
  knownAs = '';
  fatherName = '';
  motherName = '';
  phoneNumber = '';
  mobileNumber = '';
  nationalCode = '';
  passportNumber = '';
  address = '';
  countryID = 0;
  countryName = 'Choose Country';
  countryList = [];
  accepted = false;
  male = false;
  female = false;
  stringImageAddress = 'Choose file ...';
  EUsername = false;
  EPassword = false;
  EEmail = false;
  EbirthDate1 = false;
  EfirstName = false;
  ElastName = false;
  EnationalCode = false;
  ECountry = false;
  cantSubmit = false;

  EphoneNumber = false;
  EmobileNumber = false;


  constructor(private netWorks: NetworksService, public gv: GlobalVariable, private snackBar: MatSnackBar,
              private router: Router, private spinnerService: Ng4LoadingSpinnerService, private info: InfoService,
              private toast: ToastService) {
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.netWorks.getCountry(this.gv.countriesGet).subscribe((respone: ICountry[]) => {
      this.countryList = respone;
    }, () => {
    }, () => {
    });

    this.netWorks.getApplicant(this.gv.applicantsGet + '/' + this.info.id).subscribe((response: IApplicants) => {

      this.username = response.username;
      this.password = response.password;
      this.email = response.email;
      this.birthDate1 = response.birthDate;

      this.gender = response.gender;
      if (this.gender === 'm') {
        this.male = true;
        this.female = false;
      } else if (this.gender === 'f') {
        this.female = true;
        this.male = false;
      }
      this.firstName = response.firstName;
      this.lastName = response.lastName;
      this.middleName = response.middleName;
      this.knownAs = response.knownAs;
      this.fatherName = response.fatherName;
      this.motherName = response.motherName;
      this.phoneNumber = response.phoneNumber;
      this.mobileNumber = response.mobileNumber;
      this.nationalCode = response.nationalCode;
      this.passportNumber = response.passportNumber;
      this.userImage = response.avatar;
      this.countryID = response.country.id;
      this.address = response.address;
      this.countryName = response.country.name;
    }, () => {
    }, () => {
    });
  }

  isNumber(value: string | number): boolean {
    return !isNaN(Number(value.toString()));
  }


  Update() {

    if (this.username === '') {
      this.EUsername = true;
      this.cantSubmit = true;
    } else {
      this.EUsername = false;
    }
    if (this.password === '' || this.password.length < 6) {
      this.EPassword = true;
      this.cantSubmit = true;
      this.toast.toast('error', 'Error', 'Please Insert Safe Password');
      this.cantSubmit = false;
      return;
    } else {
      this.EPassword = false;
    }
    if (this.email === '') {
      this.EEmail = true;
      this.cantSubmit = true;

    } else {
      this.EEmail = false;
    }
    if (!EmailValidator.validate(this.email)) {
      this.EEmail = true;
      this.cantSubmit = true;

    } else {
      this.EEmail = false;
    }
    if (this.firstName === '') {
      this.EfirstName = true;
      this.cantSubmit = true;

    } else {
      this.EfirstName = false;
    }
    if (this.lastName === '') {
      this.ElastName = true;
      this.cantSubmit = true;

    } else {
      this.ElastName = false;
    }
    if (this.nationalCode === '' || !this.isNumber(this.nationalCode)) {
      this.EnationalCode = true;
      this.cantSubmit = true;

    } else {
      this.EnationalCode = false;
    }
    if (this.birthDate1 === '') {
      this.EbirthDate1 = true;
      this.cantSubmit = true;

    } else {
      this.EbirthDate1 = false;
    }
    if (this.countryID === 0) {
      this.ECountry = true;
      this.cantSubmit = true;
    } else {
      this.ECountry = false;
    }

    if (!this.isNumber(this.mobileNumber)) {
      this.EmobileNumber = true;
      this.cantSubmit = true;
    } else {
      this.EmobileNumber = false;
    }

    if (!this.isNumber(this.phoneNumber)) {
      this.EphoneNumber = true;
      this.cantSubmit = true;
    } else {
      this.EphoneNumber = false;
    }


    if (this.cantSubmit) {
      this.cantSubmit = false;
      return;
    }


    const formData: FormData = new FormData();
    const ImageFile = this.selectFilesInputUP.nativeElement;
    if (ImageFile.files && ImageFile.files[0]) {
      this.imageFile = ImageFile.files[0];
      const ImgFile: File = this.imageFile;
      formData.append('img', ImgFile);
      const fileExt = this.stringImageAddress.split('.').pop();
      if (fileExt !== 'jpg' && fileExt !== 'png' && fileExt !== 'PNG' && fileExt !== 'JPG') {
        this.toast.toast('error', 'Error', 'Please Insert Valid Image');
        return;
      }
    }
    formData.append('username', this.username);
    formData.append('password', this.password);
    formData.append('email', this.email);
    formData.append('birthDate', this.birthDate1);
    formData.append('gender', this.gender);
    formData.append('firstName', this.firstName);
    formData.append('lastName', this.lastName);
    formData.append('middleName', this.middleName);
    formData.append('knownAs', this.knownAs);
    formData.append('fatherName', this.fatherName);
    formData.append('motherName', this.motherName);
    formData.append('phoneNumber', this.phoneNumber);
    formData.append('mobileNumber', this.mobileNumber);
    formData.append('nationalCode', this.nationalCode);
    formData.append('passportNumber', this.passportNumber);
    formData.append('address', this.address);
    formData.append('country', this.countryID + '');
    this.spinnerService.show();
    this.netWorks.Post(this.gv.applicantsPost + '/' + this.info.id, formData).subscribe((respone) => {
      this.snackBar.open('Success', 'Profile Successfully Updated', {
          duration: 2000, verticalPosition: 'top'
        }
      );
      this.spinnerService.hide();

    }, () => {
      this.snackBar.open('Error', 'Please Fill Valid Value', {
        duration: 2000,
        verticalPosition: 'top'
      });
      this.spinnerService.hide();

    }, () => {
      this.spinnerService.hide();
    });

  }

  changeFile(event: string) {
    this.stringImageAddress = event;
  }

  handleChangeM(evt) {
    const target = evt.target;
    if (target.checked) {
      this.gender = 'm';
    }
  }

  handleChangeF(evt) {
    const target = evt.target;
    if (target.checked) {
      this.gender = 'f';
    }
  }

  onSelectCountry(selected) {
    this.countryID = selected;
  }

}
