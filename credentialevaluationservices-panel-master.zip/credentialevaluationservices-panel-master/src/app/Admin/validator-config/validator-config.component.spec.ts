import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidatorConfigComponent } from './validator-config.component';

describe('ValidatorConfigComponent', () => {
  let component: ValidatorConfigComponent;
  let fixture: ComponentFixture<ValidatorConfigComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ValidatorConfigComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidatorConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
