import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';
import {MatSnackBar} from '@angular/material';
import {IEvaluators} from '../../Models/ievaluators';
import {IUniversity} from '../../Models/iuniversity';
import {CookieConsent} from '../../cookie-consent.service';
import {ToastService} from '../../toast.service';
import * as EmailValidator from 'email-validator';

@Component({
  selector: 'app-validator-config',
  templateUrl: './validator-config.component.html',
  styleUrls: ['./validator-config.component.css']
})
export class ValidatorConfigComponent implements OnInit {

  constructor(private networks: NetworksService, public  gv: GlobalVariable,
              private spinnerService: Ng4LoadingSpinnerService, private snackBar: MatSnackBar,
              private toast: ToastService) {
  }

  listValidator: IEvaluators[];
  listValidator2: IEvaluators[];
  description = '';
  messageTitle = '';

  isSelected = false;

  @ViewChild('selectFiles') selectFilesInput: ElementRef;
  imageFile: File;

  username = '';
  password = '';
  email = '';
  firstName = '';
  lastName = '';
  phoneNumber = '';
  university = -1;
  listUniversity = [];
  message = [];
  mess = '';
  isSelectMessage = false;

  @ViewChild('selectFilesUP') selectFilesInputUP: ElementRef;
  imageFileUP: File;
  usernameUP = '';
  passwordUP = '';
  emailUP = '';
  firstNameUP = '';
  lastNameUP = '';
  phoneNumberUP = ' ';
  universityUP = -1;
  universityStringUP = '';
  avatarUP = '';
  stringImageAddress = 'Choose file ...';
  stringImageAddressUP = 'Choose file ...';
  validatorID = 0;
  Enabled = true;
  @ViewChild('myTable') table: any;



  Filter(event) {
    const val = event.target.value.toLowerCase();
    this.listValidator = this.listValidator2;
    this.listValidator = this.listValidator.filter(function (d) {
      return d.username.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }

  sendMessage() {
    if (this.messageTitle === '') {
      this.snackBar.open('Error', 'Please Insert Title', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    if (this.description === '') {
      this.snackBar.open('Error', 'Please Insert Message', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
        this.spinnerService.show();
    this.networks.Post(this.gv.messageValidator + this.validatorID, {
      'title': this.messageTitle,
      'text': this.description
    }).subscribe(() => {
      this.toast.toast('success', 'Success', 'Message Successfully Send');
      this.messageTitle = '';
      this.description = '';
      this.spinnerService.hide();
      this.load();
    }, () => {
      this.spinnerService.hide();
    });
  }

  onSelectMess({selected}) {
    this.isSelectMessage = true;
    this.mess = selected[0].text;

  }

  onSelect({selected}) {
    this.isSelected = true;
    this.usernameUP = selected[0].username;
    this.passwordUP = selected[0].password;
    this.emailUP = selected[0].email;
    this.firstNameUP = selected[0].firstName;
    this.lastNameUP = selected[0].lastName;
    this.phoneNumberUP = selected[0].phoneNumber;
    this.universityStringUP = selected[0].university.name;
    this.universityUP = selected[0].university.id;
    this.avatarUP = selected[0].avatar;
    this.validatorID = selected[0].id;
    this.message = selected[0].messages;
    this.Enabled = selected[0].verified;
  }


  changeFile(event: string) {
    this.stringImageAddress = event;
  }

  changeFileUP(event: string) {
    this.stringImageAddressUP = event;
  }

  onSubmit() {
    if (this.username === '' || this.password === '' || this.email === '' ||
      this.firstName === '' || this.lastName === '' || this.phoneNumber === '' || this.university === -1) {
      this.snackBar.open('Error', 'Please Insert All Input', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }

    if (!this.isNumber(this.phoneNumber)) {
      this.snackBar.open('Error', 'Please Insert Valid Phone Number', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }

    if (!EmailValidator.validate(this.email)) {
      this.snackBar.open('Error', 'Please Insert Valid Email Address', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    if (this.password.length < 6) {
      this.snackBar.open('Error', 'Please Insert Safe Password ', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }

    const formData: FormData = new FormData();
    const ImageFile = this.selectFilesInput.nativeElement;

    if (ImageFile.files && ImageFile.files[0]) {
      this.imageFile = ImageFile.files[0];

    } else {
      this.snackBar.open('Error', 'Please Insert Picture ', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    const fileExt = this.stringImageAddress.split('.').pop();
    if (fileExt !== 'jpg' && fileExt !== 'png' && fileExt !== 'PNG' && fileExt !== 'JPG' ) {
      this.toast.toast('error', 'Error', 'Please Insert Valid Image');
      return;
    }
    const ImgFile: File = this.imageFile;
    formData.append('img', ImgFile);
    formData.append('username', this.username);
    formData.append('password', this.password);
    formData.append('email', this.email);
    formData.append('firstName', this.firstName);
    formData.append('lastName', this.lastName);
    formData.append('phoneNumber', this.phoneNumber);
    formData.append('university', this.university + '');
    this.spinnerService.show();

    this.networks.Post(this.gv.evaluatorsPost, formData).subscribe((response) => {
      this.snackBar.open('Success', 'Validator Successfully Add', {duration: 2000});
      this.username = '';
      this.password = '';
      this.email = '';
      this.firstName = '';
      this.lastName = '';
      this.phoneNumber = '';
      this.stringImageAddress = 'Choose file ...';
      this.spinnerService.hide();

      this.load();
    }, (Error) => {
      this.snackBar.open('Error', 'This Username is Exist', {
        duration: 2000,
        verticalPosition: 'top'
      });
      this.spinnerService.hide();

    }, () => {
      this.spinnerService.hide();

    });

  }

  isNumber(value: string | number): boolean {
    return !isNaN(Number(value.toString()));
  }

  onUpdate() {
    if (this.usernameUP === '' || this.passwordUP === '' || this.emailUP === '' ||
      this.firstNameUP === '' || this.lastNameUP === '' || this.phoneNumberUP === '' || this.universityUP === -1) {
      this.snackBar.open('Error', 'Please Insert All Input', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    if (!this.isNumber(this.phoneNumberUP)) {
      this.snackBar.open('Error', 'Please Insert Valid Phone Number', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    if (!EmailValidator.validate(this.emailUP)) {
      this.snackBar.open('Error', 'Please Insert Valid Email Address', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    if (this.passwordUP.length < 6) {
      this.snackBar.open('Error', 'Please Insert Safe Password ', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }

    const formData: FormData = new FormData();
    const ImageFile = this.selectFilesInputUP.nativeElement;
    if (ImageFile.files && ImageFile.files[0]) {
      this.imageFileUP = ImageFile.files[0];
    }
    const ImgFile: File = this.imageFileUP;
    if (ImgFile != null) {
      formData.append('img', ImgFile);
      const fileExt = this.stringImageAddressUP.split('.').pop();
      if (fileExt !== 'jpg' && fileExt !== 'png' && fileExt !== 'PNG' && fileExt !== 'JPG' ) {
        this.toast.toast('error', 'Error', 'Please Insert Valid Image');
        return;
      }
    }
    formData.append('username', this.usernameUP);
    formData.append('password', this.passwordUP);
    formData.append('email', this.emailUP);
    formData.append('firstName', this.firstNameUP);
    formData.append('lastName', this.lastNameUP);
    if (this.phoneNumberUP != null) {
      formData.append('phoneNumber', this.phoneNumberUP);
    }
    formData.append('university', this.universityUP + '');
    this.spinnerService.show();

    this.networks.Post(this.gv.evaluatorsPost + '/' + this.validatorID, formData).subscribe((response) => {
      this.snackBar.open('Success', 'Validator Successfully Update', {duration: 2000, verticalPosition: 'top'});
      this.isSelected = false;
      this.spinnerService.hide();
      this.load();
    }, () => {

      this.snackBar.open('Error', 'Please Insert Valid Value', {
        duration: 2000, verticalPosition: 'top'
      });
      this.spinnerService.hide();
    }, () => {
      this.spinnerService.hide();

    });
  }


  onSelectUniversity(selected) {
    this.university = selected;
  }

  onSelectUniversityUP(selected) {
    this.universityUP = selected;
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.isSelected = false;

    this.networks.getUniversities(this.gv.universitiesGet).subscribe((response: IUniversity[]) => {
      this.listUniversity = response;
    }, () => {
    }, () => {
    });

    this.networks.getEvaluators(this.gv.evaluatorsGet).subscribe((response) => {
      this.listValidator = response;
      this.listValidator2 = response;
    });
  }

  onChangeVer() {
    this.networks.getVerified(this.gv.evaluatorsPost + '/' + this.validatorID + '/' + this.Enabled).subscribe(() => {
      if (this.Enabled) {
        this.toast.toast('success', 'Success', 'this Accreditor Successfully Enabled ');
      } else {
        this.toast.toast('info', 'Success', 'this Accreditor Successfully Disabled ');
      }
      this.load();
    });
  }
}
