import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {DeviceDetectorService} from 'ngx-device-detector';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router: Router, private route: ActivatedRoute, private deviceService: DeviceDetectorService) {
  }

  status = true;
  deviceInfo = null;

  ngOnInit() {
    this.deviceInfo = this.deviceService.getDeviceInfo();
  }

  menuSlid() {

    this.status = !this.status;
  }

  dash() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['dashboard'], {relativeTo: this.route});

      }, 600);
    } else {
      this.router.navigate(['dashboard'], {relativeTo: this.route});
    }
  }

  Acc() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['Validator'], {relativeTo: this.route});

      }, 600);
    } else {
      this.router.navigate(['Validator'], {relativeTo: this.route});

    }
  }

  Uni() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['University'], {relativeTo: this.route});
      }, 600);
    } else {
      this.router.navigate(['University'], {relativeTo: this.route});
    }

  }

  Ora() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['organizations'], {relativeTo: this.route});

      }, 600);
    } else {
      this.router.navigate(['organizations'], {relativeTo: this.route});
    }
  }

  Staff() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['staff'], {relativeTo: this.route});

      }, 600);
    } else {
      this.router.navigate(['staff'], {relativeTo: this.route});
    }


  }

  App() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['Users'], {relativeTo: this.route});

      }, 600);
    } else {
      this.router.navigate(['Users'], {relativeTo: this.route});
    }
  }

  Config() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['Config'], {relativeTo: this.route});
      }, 600);
    } else {
      this.router.navigate(['Config'], {relativeTo: this.route});
    }
  }
}
