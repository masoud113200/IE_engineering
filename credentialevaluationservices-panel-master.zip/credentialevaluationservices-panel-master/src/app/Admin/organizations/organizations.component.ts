import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';
import {MatSnackBar} from '@angular/material';
import {ToastService} from '../../toast.service';
import * as EmailValidator from 'email-validator';

@Component({
  selector: 'app-organizations',
  templateUrl: './organizations.component.html',
  styleUrls: ['./organizations.component.css']
})
export class OrganizationsComponent implements OnInit {


  constructor(private netWorks: NetworksService, private gv: GlobalVariable, private spinnerService: Ng4LoadingSpinnerService,
              private snackBar: MatSnackBar, private toast: ToastService) {
  }

  isOrganizationsSelected = false;
  listOrganizations = [];
  listOrganizations2 = [];
  listCountry = [];
  @ViewChild('selectFiles') selectFilesInput: ElementRef;
  imageFile: File;
  name = '';
  email = '';
  webSite = '';
  phoneNumber = '';
  address = '';
  countryId = -1;
  Enabled = true;

  @ViewChild('selectFilesUP') selectFilesInputUP: ElementRef;
  countryStringUP = '';
  nameUP = '';
  emailUP = '';
  webSiteUP = '';
  phoneNumberUP = '';
  addressUP = '';
  countryIdUP = -1;
  selectedOrganizationsId = 0;
  passportNumber = '';
  stringImageAddress = 'Choose file ...';
  stringImageAddressUP = 'Choose file ...';
  FName = '';


  Filter(event) {
    const val = event.target.value.toLowerCase();
    this.listOrganizations = this.listOrganizations2;
    this.listOrganizations = this.listOrganizations.filter(function (d) {
      return d.name.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }

  onSelectCountry(select) {
    this.countryIdUP = select;
    this.countryId = select;
    console.log(this.countryId);
  }

  ngOnInit() {
    this.load();
  }

  changeFile(event: string) {
    this.stringImageAddress = event;
  }

  changeFileUP(event: string) {
    this.stringImageAddressUP = event;
  }

  load() {
    this.netWorks.getOrganizations(this.gv.organizationsGet + '/admin/').subscribe((response) => {
      this.listOrganizations = response;
      this.listOrganizations2 = response;
    }, () => {
    }, () => {
    });
    this.netWorks.getCountry(this.gv.countriesGet).subscribe((response) => {
      this.listCountry = response;
    });
  }

  onSelectOrganizations({selected}) {
    this.isOrganizationsSelected = true;
    this.countryStringUP = selected[0].country.name;
    this.nameUP = selected[0].name;
    this.FName = selected[0].name;
    this.emailUP = selected[0].email;
    this.webSiteUP = selected[0].webSite;
    this.phoneNumberUP = selected[0].phoneNumber;
    this.addressUP = selected[0].address;
    this.countryIdUP = selected[0].country.id;
    this.selectedOrganizationsId = selected[0].id;
    this.Enabled = selected[0].verified;
  }

  inArray(needle: string, haystack: any): boolean {
    console.log(needle);
    console.log(haystack);
    const length = haystack.length;
    for (let i = 0; i < length; i++) {
      if (haystack[i].name.toString().toLowerCase().trim() === needle.toLowerCase().trim()) {
        return true;
      }
    }
    return false;
  }

  onUpdate() {
    if (this.nameUP === '' || this.emailUP === '' ||
      this.webSiteUP === '' || this.addressUP === '' || this.phoneNumberUP === '' || this.countryIdUP === -1) {
      this.snackBar.open('Error', 'Please Insert All Input', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }

    if (!this.isNumber(this.phoneNumberUP)) {
      this.snackBar.open('Error', 'Please Insert Valid Phone Number', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    if (!EmailValidator.validate(this.emailUP)) {
      this.snackBar.open('Error', 'Please Insert Valid Email Address', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    const formData: FormData = new FormData();
    const ImageFile = this.selectFilesInputUP.nativeElement;
    if (ImageFile.files && ImageFile.files[0]) {
      this.imageFile = ImageFile.files[0];
      const ImgFile: File = this.imageFile;
      formData.append('img', ImgFile);

      const fileExt = this.stringImageAddressUP.split('.').pop();
      if (fileExt !== 'jpg' && fileExt !== 'png' && fileExt !== 'PNG' && fileExt !== 'JPG') {
        this.toast.toast('error', 'Error', 'Please Insert Valid Image');
        return;
      }
    }
    if (this.inArray(this.nameUP, this.listOrganizations2) && this.nameUP !== this.FName) {
      this.snackBar.open('Error', 'This organization name already exists', {duration: 2000, verticalPosition: 'top'});
      return;
    }

    formData.append('name', this.nameUP);
    formData.append('email', this.emailUP);
    formData.append('webSite', this.webSiteUP);
    formData.append('phoneNumber', this.phoneNumberUP);
    formData.append('address', this.addressUP);
    formData.append('country', this.countryIdUP + '');
    console.log(this.countryIdUP);

    this.spinnerService.show();
    this.netWorks.Post(this.gv.organizationsPost + '/' + this.selectedOrganizationsId, formData).subscribe((respone) => {
      this.snackBar.open('Success', 'Organization Update Successfully', {duration: 2000, verticalPosition: 'top'});
      this.stringImageAddress = 'Choose file ...';
      this.spinnerService.hide();

      this.load();
      this.isOrganizationsSelected = false;
    }, () => {
      this.snackBar.open('Error', 'Please Insert Valid Value', {
        duration: 2000,
        verticalPosition: 'top'
      });
    }, () => {
      this.spinnerService.hide();
    });

  }

  isNumber(value: string | number): boolean {
    return !isNaN(Number(value.toString()));
  }


  onSubmit() {

    if (this.name === '' || this.email === '' ||
      this.webSite === '' || this.address === '' || this.phoneNumber === '' || this.countryId === -1) {
      this.snackBar.open('Error', 'Please Insert All Input', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    if (!this.isNumber(this.phoneNumber)) {
      this.snackBar.open('Error', 'Please Insert Valid Phone Number', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    if (!EmailValidator.validate(this.email)) {
      this.snackBar.open('Error', 'Please Insert Valid Email Address', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    const formData: FormData = new FormData();
    const ImageFile = this.selectFilesInput.nativeElement;
    if (ImageFile.files && ImageFile.files[0]) {
      this.imageFile = ImageFile.files[0];

    } else {
      this.snackBar.open('Error', 'Please Insert Picture ', {
        duration: 2000,
        verticalPosition: 'top'
      });
      return;
    }
    const ImgFile: File = this.imageFile;
    const fileExt = this.stringImageAddress.split('.').pop();
    if (fileExt !== 'jpg' && fileExt !== 'png' && fileExt !== 'PNG' && fileExt !== 'JPG') {
      this.toast.toast('error', 'Error', 'Please Insert Valid Image');
      return;
    }
    if (this.inArray(this.name, this.listOrganizations2)) {
      this.snackBar.open('Error', 'This organization name already exists', {duration: 2000, verticalPosition: 'top'});
      return;
    }
    formData.append('img', ImgFile);
    formData.append('name', this.name);
    formData.append('email', this.email);
    formData.append('webSite', this.webSite);
    formData.append('phoneNumber', this.phoneNumber);
    formData.append('address', this.address);
    formData.append('country', this.countryId + '');

    this.spinnerService.show();
    this.netWorks.Post(this.gv.organizationsPost, formData).subscribe((respone) => {
      this.snackBar.open('Success', 'Organization Add Successfully', {
        duration: 2000, verticalPosition: 'top'
      });
      this.name = '';
      this.email = '';
      this.webSite = '';
      this.phoneNumber = '';
      this.address = '';
      this.stringImageAddress = 'Choose file ...';
      this.spinnerService.hide();
      this.load();
    }, () => {
      this.snackBar.open('Error', 'Username is Exist', {
        duration: 2000,
        verticalPosition: 'top'
      });
      this.spinnerService.hide();
    }, () => {
      this.spinnerService.hide();
    });

  }

  onChangeVer() {
    this.netWorks.getVerified(this.gv.organizationsPost + '/' + this.selectedOrganizationsId + '/' + this.Enabled).subscribe(() => {
      if (this.Enabled) {
        this.toast.toast('info', 'Success', 'This organization successfully enabled ');
      } else {
        this.toast.toast('info', 'Success', 'This organization successfully disabled ');
      }
      this.load();
    });
  }
}
