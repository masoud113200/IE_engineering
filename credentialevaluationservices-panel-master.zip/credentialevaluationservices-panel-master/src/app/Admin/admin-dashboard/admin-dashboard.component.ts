import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import '../../../assets/charts/amchart/amcharts.js';
import '../../../assets/charts/amchart/gauge.js';
import '../../../assets/charts/amchart/pie.js';
import '../../../assets/charts/amchart/serial.js';
import '../../../assets/charts/amchart/light.js';
import '../../../assets/charts/amchart/ammap.js';
import '../../../assets/charts/amchart/worldLow.js';
import '../../../assets/charts/amchart/continentsLow.js';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {MatSnackBar} from '@angular/material';

declare const AmCharts: any;

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})

export class AdminDashboardComponent implements OnInit {

  constructor(private networks: NetworksService, private gv: GlobalVariable, private snackBar: MatSnackBar) {
  }

  userCount = 0;
  validatorCount = 0;
  requestCount = 0;
  acceptedCount = 0;
  chart = [];
  username = '';
  password = '';


  ngOnInit() {
    this.load();

  }

  load() {

    this.networks.getDashAdmin(this.gv.adminDashGet).subscribe((response) => {
      this.userCount = response.applicants;
      this.validatorCount = response.evaluators;
      this.requestCount = response.requests;
      this.acceptedCount = response.accepted;
      // this.chart = response.chart;
    //  console.log(this.chart);
      this.chart = response.chart.sort((obj1, obj2) => {
        if (obj1.date > obj2.date) {
          return 1;
        }
        if (obj1.date < obj2.date) {
          return -1;
        }
        return 0;
      });


      AmCharts.makeChart('statistics_chart', {
        'type': 'serial',
        'theme': 'light',
        'dataDateFormat': 'YYYY-MM-DD',
        'precision': 2,
        'valueAxes': [{
          'id': 'v1',
          'title': 'Sales',
          'position': 'left',
          'autoGridCount': false,
          'labelFunction': function (value) {
            return '$' + Math.round(value) + 'M';
          }
        }, {
          'id': 'v2',
          'gridAlpha': 0.1,
          'autoGridCount': false
        }],
        'graphs': [{
          'id': 'g1',
          'valueAxis': 'v2',
          'lineThickness': 0,
          'fillAlphas': 0.2,
          'lineColor': '#4099ff',
          'type': 'line',
          'title': 'All Request',
          'useLineColorForBulletBorder': true,
          'valueField': 'requests',
          'balloonText': '[[title]]<br /><b style="font-size: 130%">[[value]]</b>'
        }],
        'chartCursor': {
          'pan': true,
          'valueLineEnabled': true,
          'valueLineBalloonEnabled': true,
          'cursorAlpha': 0,
          'valueLineAlpha': 0.2
        },
        'categoryField': 'date',
        'categoryAxis': {
          'parseDates': true,
          'gridAlpha': 0,
          'minorGridEnabled': true
        },
        'legend': {
          'position': 'top',
        },
        'balloon': {
          'borderThickness': 1,
          'shadowAlpha': 0
        },
        'export': {
          'enabled': true
        },
        'dataProvider': this.chart
      });

    });

  }
}
