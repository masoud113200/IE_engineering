import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminDashbardComponent } from './admin-dashboard.component';

describe('AdminDashbardComponent', () => {
  let component: AdminDashbardComponent;
  let fixture: ComponentFixture<AdminDashbardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdminDashbardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminDashbardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
