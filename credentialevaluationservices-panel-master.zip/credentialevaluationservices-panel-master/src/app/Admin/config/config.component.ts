import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {MatSnackBar} from '@angular/material';
import {ToastService} from '../../toast.service';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';
import {ICountry} from '../../Models/icountry';

@Component({
  selector: 'app-config',
  templateUrl: './config.component.html',
  styleUrls: ['./config.component.css']
})
export class ConfigComponent implements OnInit {

  ListCountry = [];
  ListCountry2 = [];
  ListGrad = [];
  ListGrad2 = [];
  isCountrySelected = false;
  isUniversitySelected = false;
  CountryName = '';
  DegreeLevel = '';

  CountryNameUP = '';
  DegreeLevelUP = '';
  CountryNameID = 0;
  DegreeLevelID = 0;
  EnabledCountry = true;
  EnabledDegreeLevel = true;

  adminUsername = '';
  adminPassword = '';
  stringImageAddress = 'Choose file ...';
  @ViewChild('selectFiles') selectFilesInputUP: ElementRef;
  imageFile: File;

  constructor(private netWorks: NetworksService, private gv: GlobalVariable, private snackBar: MatSnackBar, private toast: ToastService, private spinnerService: Ng4LoadingSpinnerService) {
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.netWorks.getAdmin(this.gv.adminGet).subscribe((response) => {
      this.adminUsername = response.username;
      this.adminPassword = response.password;
    });
    this.netWorks.getCountry(this.gv.countriesGet + '/admin').subscribe((response) => {
      this.ListCountry = response;
      this.ListCountry2 = response;
    });
    this.netWorks.getGrad(this.gv.gradesGet + '/admin').subscribe((response) => {
      this.ListGrad = response;
      this.ListGrad2 = response;
    });

  }

  onSubmit() {

    if (this.adminPassword === '' || this.adminPassword.length < 6) {

      this.toast.toast('error', 'Error', 'Please Insert Safe Password');
      return;
    }
    if (this.adminPassword === '') {
      this.toast.toast('error', 'Error', 'Please Insert Username');
      return;
    }
    this.spinnerService.show();

    const formData: FormData = new FormData();
    const ImageFile = this.selectFilesInputUP.nativeElement;
    if (ImageFile.files && ImageFile.files[0]) {
      this.imageFile = ImageFile.files[0];
    }
    const ImgFile: File = this.imageFile;
    formData.append('img', ImgFile);
    formData.append('username', this.adminUsername);
    formData.append('password', this.adminPassword);

    this.netWorks.Post(this.gv.adminPost, formData).subscribe(() => {
      this.snackBar.open('Success', 'Update Admin', {
        duration: 2000, verticalPosition: 'top'
      });
      this.spinnerService.hide();
    }, () => {
      this.spinnerService.hide();
    });
  }

  changeFile(event: string) {
    this.stringImageAddress = event;
  }

  FilterC(event) {
    const val = event.target.value.toLowerCase();
    this.ListCountry = this.ListCountry2;
    this.ListCountry = this.ListCountry.filter(function (d) {
      return d.name.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }

  FilterD(event) {
    const val = event.target.value.toLowerCase();
    this.ListGrad = this.ListGrad2;
    this.ListGrad = this.ListGrad.filter(function (d) {
      return d.name.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }

  inArray(needle: string, haystack: any): boolean {
    console.log(needle);
    console.log(haystack);
    const length = haystack.length;
    for (let i = 0; i < length; i++) {
      if (haystack[i].name.toString().toLowerCase().trim() === needle.toLowerCase().trim()) {
        return true;
      }
    }
    return false;
  }

  submitCountry() {

    if (this.CountryName === '') {
      this.snackBar.open('Error', 'Please Insert Country Title', {duration: 2000, verticalPosition: 'top'});
      return;
    }
    if (this.inArray(this.CountryName, this.ListCountry2)) {
      this.snackBar.open('Error', 'This country already exists', {duration: 2000, verticalPosition: 'top'});
      return;
    }
    this.netWorks.Post(this.gv.countriesPost, {
      name: this.CountryName
    }).subscribe(() => {
      this.snackBar.open('Success', 'Country Add Successfully', {duration: 2000, verticalPosition: 'top'});
      this.CountryName = '';
      this.load();
    });
  }

  submitDegree() {
    if (this.DegreeLevel === '') {
      this.snackBar.open('Error', 'Please Insert Degree Level Title', {duration: 2000, verticalPosition: 'top'});
      return;
    }
    if (this.inArray(this.DegreeLevel, this.ListGrad2)) {
      this.snackBar.open('Error', 'This Degree Level already exists', {duration: 2000, verticalPosition: 'top'});
      return;
    }
    this.netWorks.Post(this.gv.gradesPost, {
      name: this.DegreeLevel
    }).subscribe(() => {
      this.snackBar.open('Success', 'Degree Level Add Successfully', {duration: 2000, verticalPosition: 'top'});
      this.DegreeLevel = '';
      this.load();
    });
  }

  upDateCountry() {
    this.netWorks.Post(this.gv.countriesPost + '/' + this.CountryNameID, {
      name: this.CountryNameUP
    }).subscribe(() => {
      this.snackBar.open('Success', 'Country Updated Successfully', {duration: 2000, verticalPosition: 'top'});
      this.load();
    });
  }

  upDateDegree() {
    this.netWorks.Post(this.gv.gradesPost + '/' + this.DegreeLevelID, {
      name: this.DegreeLevelUP
    }).subscribe(() => {
      this.snackBar.open('Success', 'Degree Level Updated Successfully', {duration: 2000, verticalPosition: 'top'});
      this.load();
    });
  }

  delCountry() {
    if (!confirm('Are You Sure Delete Country')) {
      return;
    }
    this.netWorks.del(this.gv.countriesPost + '/' + this.CountryNameID).subscribe(() => {
      this.snackBar.open('Success', 'Country Delete Successfully', {duration: 2000, verticalPosition: 'top'});
      this.CountryNameUP = '';
      this.load();
      this.isCountrySelected = false;

    }, () => {
      this.snackBar.open('Error', 'This Country is Used', {duration: 2000, verticalPosition: 'top'});

    });
  }

  delDegree() {
    if (!confirm('Are You Sure Delete Degree Level')) {
      return;
    }
    this.netWorks.del(this.gv.gradesPost + '/' + this.DegreeLevelID).subscribe(() => {
      this.snackBar.open('Success', 'Degree Level Delete Successfully', {duration: 2000, verticalPosition: 'top'});
      this.DegreeLevelUP = '';
      this.isUniversitySelected = false;
      this.load();
    }, () => {
      this.snackBar.open('Error', 'This Degree Level is Used', {duration: 2000, verticalPosition: 'top'});

    });
  }

  onSelectDegree({selected}) {
    this.isUniversitySelected = true;
    this.DegreeLevelUP = selected[0].name;
    this.DegreeLevelID = selected[0].id;
    this.EnabledDegreeLevel = selected[0].verified;

  }

  onSelectCountry({selected}) {
    this.isCountrySelected = true;
    this.CountryNameUP = selected[0].name;
    this.CountryNameID = selected[0].id;
    this.EnabledCountry = selected[0].verified;
  }

  onChangeVerCo() {
    this.netWorks.getVerified(this.gv.countriesPost + '/' + this.CountryNameID + '/' + this.EnabledCountry).subscribe(() => {
      if (this.EnabledCountry) {
        this.toast.toast('info', 'Success', 'this Country Successfully Enabled ');
      } else {
        this.toast.toast('info', 'Success', 'this Country Successfully Disabled ');
      }
      this.load();
    });
  }

  onChangeVerDe() {
    this.netWorks.getVerified(this.gv.gradesPost + '/' + this.DegreeLevelID + '/' + this.EnabledDegreeLevel).subscribe(() => {
      if (this.EnabledDegreeLevel) {
        this.toast.toast('info', 'Success', 'this Degree Level Successfully Enabled ');
      } else {
        this.toast.toast('info', 'Success', 'this Degree Level Successfully Disabled ');
      }
      this.load();
    });
  }
}
