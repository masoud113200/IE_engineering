import {Component, OnInit} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {Ng4LoadingSpinnerService} from 'ng4-loading-spinner';
import {IApplicants} from '../../Models/iapplicants';
import {ToastService} from '../../toast.service';
import {IUniversity} from '../../Models/iuniversity';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  options: Object;

  description = '';
  applicantsList: IApplicants[];
  applicantsList2: IApplicants[];
  isSelected = false;
  applicant: IApplicants;
  Enabled = true;
  resultArray = ['No Action', 'In progress', 'Reject', 'Accept'];
  color = ['black', 'blue', 'red', 'green'];
  listRequestSub = [];
  listRequestSub2 = [];
  isSelectedSub = false;
  degreeImage = '';
  startDateR = '';
  endDateR = '';
  facultyR = '';
  majorR = '';
  descriptionR = '';
  gradeR = '';
  LitigationUniversities = [];
  originUniversities: IUniversity;
  status = 0;
  requestId = 0;
  imageFileSaved = '';
  messageTitle = '';
  message = [];

  editable = false;
  result = '';
  selectedStyle = 'alert alert-danger';
  saveComment = '';
  mess = '';
  isSelectMessage = false;

  constructor(private networks: NetworksService, public  gv: GlobalVariable,
              private spinnerService: Ng4LoadingSpinnerService, private toast: ToastService) {
  }

  sendMessage() {
    this.spinnerService.show();
    this.networks.Post(this.gv.messageApplicant + this.applicant.id, {
      'title': this.messageTitle,
      'text': this.description
    }).subscribe(() => {
      this.toast.toast('success', 'Success', 'Message Successfully Send');
      this.messageTitle = '';
      this.description = '';
      this.spinnerService.hide();
      this.load();
    }, () => {
      this.spinnerService.hide();
    });
  }
  onSelectMess({selected}) {
    this.isSelectMessage = true;
    this.mess = selected[0].text;

  }



  onSelect({selected}) {
    this.isSelected = true;
    this.applicant = selected[0];
    this.Enabled = this.applicant.verified;
    this.listRequestSub = selected[0].requests;
    this.listRequestSub2 = selected[0].requests;
    this.message = selected[0].messages;

  }

  Filter(event) {
    const val = event.target.value.toLowerCase();
    this.applicantsList = this.applicantsList2;
    this.applicantsList = this.applicantsList.filter(function (d) {
      return d.username.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }

  FilterS(event) {
    const val = event.target.value.toLowerCase();
    this.listRequestSub = this.listRequestSub2;
    this.listRequestSub = this.listRequestSub.filter(function (d) {
      return d.grade.name.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }

  onSelectSub({selected}) {
    this.isSelectedSub = true;
    this.degreeImage = selected[0].degreeImage;
    this.startDateR = selected[0].startDate;
    this.endDateR = selected[0].endDate;
    this.facultyR = selected[0].faculty;
    this.majorR = selected[0].major;
    this.descriptionR = selected[0].description;
    this.gradeR = selected[0].grade.name;
    this.LitigationUniversities = selected[0].destinationOrganizations;
    this.originUniversities = selected[0].originUniversity;
    this.status = selected[0].status;
    this.requestId = selected[0].id;
    this.imageFileSaved = selected[0].degreeImage;

    console.log(this.status);

    if (this.status === 3) {
      this.result = 'Request is Accepted';
      this.editable = false;
      this.selectedStyle = 'alert alert-success';
    } else if (this.status === 0) {
      this.result = '';
      this.selectedStyle = '';
      this.editable = true;

    } else if (this.status === 2) {
      this.result = 'Request is Rejected';
      this.selectedStyle = 'alert alert-danger';
      this.editable = true;

    } else if (this.status === 1) {
      this.result = 'Request is in Progress';
      this.selectedStyle = 'alert alert-info';
      this.editable = true;

    }
  }

  ngOnInit() {
    this.options = {
      charCounterCount: true,
      imageUploadParam: 'file',
      imageUploadURL: this.gv.addMedia,
      imageUploadParams: {id: 'file'},
      imageUploadMethod: 'POST',
      imageMaxSize: 5 * 1024 * 1024,
      imageAllowedTypes: ['jpeg', 'jpg', 'png'],
      videoUploadParam: 'file',
      videoUploadURL: this.gv.addMedia,
      videoUploadParams: {id: 'my_editor'},
      videoUploadMethod: 'POST',
      videoMaxSize: 50 * 1024 * 1024,
      fileUploadParam: 'file',
      fileUploadURL: this.gv.addMedia,
      fileUploadParams: {id: 'my_editor'},
      fileUploadMethod: 'POST',
      fileMaxSize: 20 * 1024 * 1024,
      fileAllowedTypes: ['*'],
      placeholderText: 'Insert Text'
    };

    this.load();
  }

  load() {
    this.isSelected = false;
    this.networks.getApplicants(this.gv.applicantsGet).subscribe((response) => {
      this.applicantsList = response;
      this.applicantsList2 = response;
    });
  }


  onChangeVer() {
    this.networks.getVerified(this.gv.applicantsPost + '/' + this.applicant.id + '/' + this.Enabled).subscribe(() => {
      if (this.Enabled) {
        this.toast.toast('info', 'Success', 'this Applicant Successfully Enabled ');
      } else {
        this.toast.toast('info', 'Success', 'this Applicant Successfully Disabled ');
      }
      this.load();
    });
  }
}
