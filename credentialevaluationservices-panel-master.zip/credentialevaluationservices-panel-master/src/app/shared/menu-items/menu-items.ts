import {Injectable} from '@angular/core';

export interface BadgeItem {
  type: string;
  value: string;
}

export interface ChildrenItems {
  state: string;
  target?: boolean;
  name: string;
  type?: string;
  children?: ChildrenItems[];
}

export interface MainMenuItems {
  state: string;
  short_label?: string;
  main_state?: string;
  target?: boolean;
  name: string;
  type: string;
  icon: string;
  badge?: BadgeItem[];
  children?: ChildrenItems[];
}

export interface Menu {
  label: string;
  main: MainMenuItems[];
}

const MENUITEMS = [
  {
    label: 'Navigation',
    main: [
      {
        state: 'dashboard',
        short_label: 'D',
        name: 'Dashboard',
        type: 'link',
        icon: 'ti-home',
        admin: true
      }, {
        state: 'administrator',
        short_label: 'D',
        name: 'Administrator',
        type: 'link',
        icon: 'ti-agenda',
        admin: true
      },
      {
        state: 'images',
        short_label: 'C',
        name: 'Image Gallery',
        type: 'sub',
        icon: 'ti-image',
        admin: true,
        children: [
          {
            state: 'images',
            name: 'Images'
          },
          {
            state: 'groups',
            name: 'Groups'
          }]
      },
      {
        state: 'videos',
        short_label: 'C',
        name: 'Video Gallery',
        type: 'sub',
        icon: 'ti-video-clapper',
        admin: true,
        children: [
          {
            state: 'videos',
            name: 'Videos'
          },
          {
            state: 'groups',
            name: 'Groups'
          }]
      },
      {
        state: 'content',
        short_label: 'G',
        name: 'Content',
        type: 'sub',
        icon: 'ti-text',
        admin: true,
        children: [
          {
            state: 'content',
            name: 'Content'
          },
          {
            state: 'groups',
            name: 'Groups'
          }]
      },

      {
        state: 'news',
        short_label: 'G',
        name: 'News',
        type: 'sub',
        icon: 'ti-microphone',
        admin: false,
        children: [
          {
            state: 'news',
            name: 'News'
          },
          {
            state: 'groups',
            name: 'Groups'
          }]

      }
      ,
      {
        state: 'help',
        short_label: 'G',
        name: 'Help',
        type: 'sub',
        icon: 'ti-help',
        admin: true,
        children: [
          {
            state: 'help',
            name: 'Help'
          },
          {
            state: 'groups',
            name: 'Groups'
          }]
      },
      {
        state: 'users',
        short_label: 'G',
        name: 'Users',
        type: 'sub',
        icon: 'ti-user',
        admin: true,
        children: [
          {
            state: 'users',
            name: 'Users'
          },
          {
            state: 'message',
            name: 'Massage'
          }]
      },
      {
        state: 'configure',
        short_label: 'G',
        name: 'Configure',
        type: 'sub',
        icon: 'ti-settings',
        admin: false,
        children: [
          {
            state: 'about',
            name: 'About Config'
          }
        ]
      }
    ]
  }
];

@Injectable()
export class MenuItems {
  getAll(): Menu[] {
    return MENUITEMS;
  }
}
