import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {DeviceDetectorService} from 'ngx-device-detector';

@Component({
  selector: 'app-staff',
  templateUrl: './staff.component.html',
  styleUrls: ['./staff.component.css']
})
export class StaffComponent implements OnInit {

  constructor(private router: Router, private route: ActivatedRoute, private deviceService: DeviceDetectorService) {
  }

  status = true;

  ngOnInit() {
  }

  menuSlid() {
    this.status = !this.status;
  }

  dash() {
    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['dashboard'], {relativeTo: this.route});

      }, 600);
    } else {
      this.router.navigate(['dashboard'], {relativeTo: this.route});
    }

  }

  repository() {

    if (this.deviceService.isMobile()) {
      this.status = !this.status;
      setTimeout(() => {
        this.router.navigate(['repository'], {relativeTo: this.route});

      }, 600);
    } else {
      this.router.navigate(['repository'], {relativeTo: this.route});

    }
  }


}
