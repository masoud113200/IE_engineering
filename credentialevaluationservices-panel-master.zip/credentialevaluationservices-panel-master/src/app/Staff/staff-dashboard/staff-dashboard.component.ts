import {Component, OnInit} from '@angular/core';

declare const AmCharts: any;

import '../../../assets/charts/amchart/amcharts.js';
import '../../../assets/charts/amchart/gauge.js';
import '../../../assets/charts/amchart/pie.js';
import '../../../assets/charts/amchart/serial.js';
import '../../../assets/charts/amchart/light.js';
import '../../../assets/charts/amchart/ammap.js';
import '../../../assets/charts/amchart/worldLow.js';
import '../../../assets/charts/amchart/continentsLow.js';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {InfoService} from '../../info.service';

@Component({
  selector: 'app-validator-dashboard',
  templateUrl: './staff-dashboard.component.html',
  styleUrls: ['./staff-dashboard.component.css']
})
export class StaffDashboardComponent implements OnInit {

  constructor(private networks: NetworksService, private gv: GlobalVariable, private info: InfoService) {
  }

  listMessage = [];
  isSelectMessage = false;
  Message = '';
  requestCount = 0;
  notCheckCount = 0;
  chart = [];
  name = '';

  ngOnInit() {
    this.load();


  }

  load() {
    this.networks.getValidatorDash(this.gv.staffDashGet + this.info.id).subscribe((response) => {
      this.requestCount = response.requests;
      this.notCheckCount = response.remaining;
      this.chart = response.chart.sort((obj1, obj2) => {
        if (obj1.date > obj2.date) {
          return 1;
        }
        if (obj1.date < obj2.date) {
          return -1;
        }
        return 0;
      });
      this.listMessage = response.messages;
      AmCharts.makeChart('statistics_chart', {
        'type': 'serial',
        'theme': 'light',
        'dataDateFormat': 'YYYY-MM-DD',
        'precision': 2,
        'valueAxes': [{
          'id': 'v1',
          'title': 'Sales',
          'position': 'left',
          'autoGridCount': false,
          'labelFunction': function (value) {
            return '$' + Math.round(value) + 'M';
          }
        }, {
          'id': 'v2',
          'gridAlpha': 0.1,
          'autoGridCount': false
        }],
        'graphs': [{
          'id': 'g1',
          'valueAxis': 'v2',
          'lineThickness': 0,
          'fillAlphas': 0.2,
          'lineColor': '#4099ff',
          'type': 'line',
          'title': 'All Request',
          'useLineColorForBulletBorder': true,
          'valueField': 'requests',
          'balloonText': '[[title]]<br /><b style="font-size: 130%">[[value]]</b>'
        }],
        'chartCursor': {
          'pan': true,
          'valueLineEnabled': true,
          'valueLineBalloonEnabled': true,
          'cursorAlpha': 0,
          'valueLineAlpha': 0.2
        },
        'categoryField': 'date',
        'categoryAxis': {
          'parseDates': true,
          'gridAlpha': 0,
          'minorGridEnabled': true
        },
        'legend': {
          'position': 'top',
        },
        'balloon': {
          'borderThickness': 1,
          'shadowAlpha': 0
        },
        'export': {
          'enabled': true
        },
        'dataProvider': this.chart
      });

    });
  }

  onSelect({selected}) {
    this.isSelectMessage = true;
    this.Message = selected[0].text;

  }
}
