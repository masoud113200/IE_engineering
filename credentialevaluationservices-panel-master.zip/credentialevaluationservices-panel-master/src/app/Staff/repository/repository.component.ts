import {Component, OnInit} from '@angular/core';
import {NetworksService} from '../../networks.service';
import {GlobalVariable} from '../../globalVariable';
import {InfoService} from '../../info.service';

@Component({
  selector: 'app-repository',
  templateUrl: './repository.component.html',
  styleUrls: ['./repository.component.css']
})
export class RepositoryComponent implements OnInit {

  constructor(private networks: NetworksService, private gv: GlobalVariable, private info: InfoService) {
  }

  listRequest = [];
  listRequest2 = [];
  listRequestSub = [];
  listRequestSub2 = [];
  isSelected = false;
  Filter(event) {
    const val = event.target.value.toLowerCase();
    this.listRequest = this.listRequest2;
    this.listRequest = this.listRequest.filter(function (d) {
      return d.username.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }
  FilterS(event) {
    const val = event.target.value.toLowerCase();
    this.listRequestSub = this.listRequestSub2;
    this.listRequestSub = this.listRequestSub.filter(function (d) {
      return d.key.digits.toLowerCase().indexOf(val) !== -1 || !val;
    });
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.networks.getApplicantRequest(this.gv.applicantRequestDestinationGet + this.info.id).subscribe((response) => {
      this.listRequest = response;
      this.listRequest2 = response;
    });
  }

  onSelect({selected}) {
    this.listRequestSub = selected[0].requests;
    this.listRequestSub2 = selected[0].requests;
    this.isSelected = true;
  }
}
