package com.cyberoxi.models;

import com.cyberoxi.models.audits.AuditModel;

import javax.persistence.Entity;


@Entity
public class AdminDashboard extends AuditModel {
    private int userCount;
    private int validatorCount;
    private int requestCount;
    private int acceptedCount;

    public int getUserCount() {
        return userCount;
    }

    public void setUserCount(int userCount) {
        this.userCount = userCount;
    }

    public int getValidatorCount() {
        return validatorCount;
    }

    public void setValidatorCount(int validatorCount) {
        this.validatorCount = validatorCount;
    }

    public int getRequestCount() {
        return requestCount;
    }

    public void setRequestCount(int requestCount) {
        this.requestCount = requestCount;
    }

    public int getAcceptedCount() {
        return acceptedCount;
    }

    public void setAcceptedCount(int acceptedCount) {
        this.acceptedCount = acceptedCount;
    }
}
