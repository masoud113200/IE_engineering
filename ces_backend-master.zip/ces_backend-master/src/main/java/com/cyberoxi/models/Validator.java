package com.cyberoxi.models;

import com.cyberoxi.models.audits.AuditModel;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import java.util.List;

@Entity
public class Validator extends AuditModel {
    private String thumbnail;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String email;
    @OneToOne
    private University university;
    @OneToMany(orphanRemoval = true, cascade = CascadeType.ALL)
    private List<Message> messages;
    @OneToMany(orphanRemoval = true, cascade = CascadeType.ALL)
    private Request request;
    @OneToMany(orphanRemoval = true, cascade = CascadeType.ALL)
    private Request Key;

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public University getUniversity() {
        return university;
    }

    public void setUniversity(University university) {
        this.university = university;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    public Request getRequest() {
        return request;
    }

    public void setRequest(Request request) {
        this.request = request;
    }

    public Request getKey() {
        return Key;
    }

    public void setKey(Request key) {
        Key = key;
    }
}
