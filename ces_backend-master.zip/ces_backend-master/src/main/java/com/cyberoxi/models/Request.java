package com.cyberoxi.models;

import com.cyberoxi.models.audits.AuditModel;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Request extends AuditModel {
    @OneToOne
    private Applicant applicant;
    private String degreePic;
    private String country;
    @OneToOne
    private University originUniversity;
    @OneToMany
    private University destinationOriginUniversity;
    private String dateOfBeginning;
    private String dateOfEnd;
    private String Faculty;
    private String Major;
    @OneToOne
    private DegreeLevel degreeLevel;
    private String nationalCode;
    private String commentApplicant;
    private String commentValidator;
    private int status;

    public Applicant getApplicant() {
        return applicant;
    }

    public void setApplicant(Applicant applicant) {
        this.applicant = applicant;
    }

    public String getDegreePic() {
        return degreePic;
    }

    public void setDegreePic(String degreePic) {
        this.degreePic = degreePic;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public University getOriginUniversity() {
        return originUniversity;
    }

    public void setOriginUniversity(University originUniversity) {
        this.originUniversity = originUniversity;
    }

    public University getDestinationOriginUniversity() {
        return destinationOriginUniversity;
    }

    public void setDestinationOriginUniversity(University destinationOriginUniversity) {
        this.destinationOriginUniversity = destinationOriginUniversity;
    }

    public String getDateOfBeginning() {
        return dateOfBeginning;
    }

    public void setDateOfBeginning(String dateOfBeginning) {
        this.dateOfBeginning = dateOfBeginning;
    }

    public String getDateOfEnd() {
        return dateOfEnd;
    }

    public void setDateOfEnd(String dateOfEnd) {
        this.dateOfEnd = dateOfEnd;
    }

    public String getFaculty() {
        return Faculty;
    }

    public void setFaculty(String faculty) {
        Faculty = faculty;
    }

    public String getMajor() {
        return Major;
    }

    public void setMajor(String major) {
        Major = major;
    }

    public DegreeLevel getDegreeLevel() {
        return degreeLevel;
    }

    public void setDegreeLevel(DegreeLevel degreeLevel) {
        this.degreeLevel = degreeLevel;
    }

    public String getNationalCode() {
        return nationalCode;
    }

    public void setNationalCode(String nationalCode) {
        this.nationalCode = nationalCode;
    }

    public String getCommentApplicant() {
        return commentApplicant;
    }

    public void setCommentApplicant(String commentApplicant) {
        this.commentApplicant = commentApplicant;
    }

    public String getCommentValidator() {
        return commentValidator;
    }

    public void setCommentValidator(String commentValidator) {
        this.commentValidator = commentValidator;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
