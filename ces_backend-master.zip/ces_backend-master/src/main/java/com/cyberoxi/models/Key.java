package com.cyberoxi.models;

import com.cyberoxi.models.audits.AuditModel;

import javax.persistence.Entity;
import javax.persistence.OneToOne;

@Entity
public class Key extends AuditModel {
    private String uniqKey;
    @OneToOne
    private Applicant applicant;
    @OneToOne
    private Request request;

    public String getUniqKey() {
        return uniqKey;
    }

    public void setUniqKey(String uniqKey) {
        this.uniqKey = uniqKey;
    }
}
