package com.cyberoxi.models;

import com.cyberoxi.models.audits.AuditModel;

import javax.persistence.Entity;

@Entity
public class DegreeLevel extends AuditModel {
    private String name;
}
