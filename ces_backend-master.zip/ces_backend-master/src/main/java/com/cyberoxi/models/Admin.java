package com.cyberoxi.models;

import com.cyberoxi.models.audits.AuditModel;

import javax.persistence.Entity;

@Entity
public class Admin extends AuditModel {
    private String userName;
    private String password;

}
