package com.cyberoxi.models;


import com.cyberoxi.models.audits.AuditModel;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "messages")
public class Message extends AuditModel {

    private String title;

    @Column(columnDefinition = "text")
    private String text;

    public String getTitle() {
        return title;
    }


    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }


}
