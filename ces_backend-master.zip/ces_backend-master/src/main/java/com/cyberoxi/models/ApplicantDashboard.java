package com.cyberoxi.models;

import com.cyberoxi.models.audits.AuditModel;

import javax.persistence.Entity;

@Entity
public class ApplicantDashboard extends AuditModel {
    private int messageCount;
    private String credit;
    private int requestCount;
    private int acceptedCount;

    public int getMessageCount() {
        return messageCount;
    }

    public void setMessageCount(int messageCount) {
        this.messageCount = messageCount;
    }

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit;
    }

    public int getRequestCount() {
        return requestCount;
    }

    public void setRequestCount(int requestCount) {
        this.requestCount = requestCount;
    }

    public int getAcceptedCount() {
        return acceptedCount;
    }

    public void setAcceptedCount(int acceptedCount) {
        this.acceptedCount = acceptedCount;
    }
}
