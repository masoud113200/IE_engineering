package com.cyberoxi;

public class GlobalAddress {
    public static String SERVER_ADDRESS = "http://185.119.166.167:5902/";
}
